#!/usr/bin/env python3
"""成绩录入系统 - 零依赖后端（Python 3.8+，仅用标准库 + SQLite）"""
import json, sqlite3, hashlib, secrets, re, sys, datetime as dt
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path

BASE = Path(__file__).parent
DB = BASE / "grades.db"
TOKENS = {}
TABLES = {"students": ["student_no", "name", "class_name"], "courses": ["code", "name", "credit"]}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, salt TEXT, pwd TEXT);
CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, student_no TEXT UNIQUE NOT NULL, name TEXT NOT NULL, class_name TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS courses(id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, credit REAL DEFAULT 1);
CREATE TABLE IF NOT EXISTS scores(id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL REFERENCES students(id),
  course_id INTEGER NOT NULL REFERENCES courses(id), term TEXT NOT NULL, score REAL NOT NULL, updated_at TEXT,
  UNIQUE(student_id, course_id, term));
"""


class ApiError(Exception):
    def __init__(self, msg, code=400): self.msg, self.code = msg, code


def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON"); return c


def hp(pw, salt): return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 100_000).hex()
def rows(c, sql, a=()): return [dict(r) for r in c.execute(sql, a).fetchall()]


def init():
    with db() as c:
        c.executescript(SCHEMA)
        if not c.execute("SELECT 1 FROM users").fetchone():
            s = secrets.token_hex(8)
            c.execute("INSERT INTO users(username,salt,pwd) VALUES('admin',?,?)", (s, hp("admin123", s)))
        if not c.execute("SELECT 1 FROM students").fetchone():
            c.executemany("INSERT INTO students(student_no,name,class_name) VALUES(?,?,?)", [
                ("2026001", "王小明", "一班"), ("2026002", "李华", "一班"), ("2026003", "赵敏", "一班"),
                ("2026004", "陈静", "二班"), ("2026005", "刘洋", "二班"), ("2026006", "周杰", "二班")])
            c.executemany("INSERT INTO courses(code,name,credit) VALUES(?,?,?)",
                          [("C001", "高等数学", 4), ("C002", "大学英语", 3), ("C003", "程序设计", 3)])


def need(body, *keys):
    for k in keys:
        if not str(body.get(k, "")).strip(): raise ApiError("请填写必填项")


def num(v, name):
    try: return int(v)
    except (TypeError, ValueError): raise ApiError(f"{name}参数无效")


def list_items(c, kind, q):
    cols = TABLES[kind]; kw = f"%{q.get('q', [''])[0].strip()}%"
    where = " OR ".join(f"{k} LIKE ?" for k in cols)
    order = "class_name,student_no" if kind == "students" else "code"
    return rows(c, f"SELECT * FROM {kind} WHERE {where} ORDER BY {order}", [kw] * len(cols))


def save_item(c, kind, body, id=None):
    cols = TABLES[kind]; need(body, cols[0], cols[1])
    vals = [str(body.get(k, "")).strip() for k in cols]
    if kind == "courses":
        try: vals[2] = float(vals[2] or 1)
        except ValueError: raise ApiError("学分必须是数字")
        if vals[2] <= 0: raise ApiError("学分必须大于 0")
    sets = ",".join(f"{k}=?" for k in cols)
    try:
        if id is None: c.execute(f"INSERT INTO {kind}({','.join(cols)}) VALUES({','.join('?' * len(cols))})", vals)
        else: c.execute(f"UPDATE {kind} SET {sets} WHERE id=?", vals + [id])
    except sqlite3.IntegrityError:
        raise ApiError("学号已存在" if kind == "students" else "课程代码已存在")
    return {"ok": True}


def delete_item(c, kind, id):
    col = "student_id" if kind == "students" else "course_id"
    c.execute(f"DELETE FROM scores WHERE {col}=?", (id,)); c.execute(f"DELETE FROM {kind} WHERE id=?", (id,))
    return {"ok": True}


def get_scores(c, q):
    g = lambda k: q.get(k, [""])[0]
    if g("student_id"):
        return rows(c, """SELECT s.*, co.code, co.name AS course_name, co.credit FROM scores s
                          JOIN courses co ON co.id=s.course_id WHERE s.student_id=? ORDER BY s.term DESC, co.code""",
                    [num(g("student_id"), "学生")])
    if g("course_id") and g("term"):
        return rows(c, """SELECT st.id AS student_id, st.student_no, st.name, st.class_name, sc.score FROM students st
                          LEFT JOIN scores sc ON sc.student_id=st.id AND sc.course_id=? AND sc.term=?
                          ORDER BY st.class_name, st.student_no""", [num(g("course_id"), "课程"), g("term")])
    raise ApiError("缺少查询参数")


def save_scores(c, body):
    cid, term = num(body.get("course_id"), "课程"), str(body.get("term", "")).strip()
    if not term: raise ApiError("请填写学期")
    if not c.execute("SELECT 1 FROM courses WHERE id=?", (cid,)).fetchone(): raise ApiError("课程不存在", 404)
    parsed = []
    for it in body.get("items") or []:          # 先全部校验，再统一写入
        sid, v = num(it.get("student_id"), "学生"), it.get("score")
        if v is None or str(v).strip() == "": parsed.append((sid, None)); continue
        try: f = float(v)
        except ValueError: raise ApiError(f"成绩不是数字：{v}")
        if not 0 <= f <= 100: raise ApiError(f"成绩必须在 0–100 之间：{v}")
        parsed.append((sid, round(f, 1)))
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        for sid, f in parsed:
            if f is None: c.execute("DELETE FROM scores WHERE student_id=? AND course_id=? AND term=?", (sid, cid, term))
            else: c.execute("""INSERT INTO scores(student_id,course_id,term,score,updated_at) VALUES(?,?,?,?,?)
                ON CONFLICT(student_id,course_id,term) DO UPDATE SET score=excluded.score, updated_at=excluded.updated_at""",
                            (sid, cid, term, f, now))
    except sqlite3.IntegrityError:
        raise ApiError("包含不存在的学生")
    return {"ok": True, "saved": sum(1 for _, f in parsed if f is not None)}


def route(method, path, q, body, token):
    if path == "/api/login" and method == "POST":
        with db() as c:
            u = c.execute("SELECT * FROM users WHERE username=?", (body.get("username", ""),)).fetchone()
        if not u or not secrets.compare_digest(u["pwd"], hp(body.get("password", ""), u["salt"])):
            raise ApiError("用户名或密码错误", 403)
        t = secrets.token_hex(16); TOKENS[t] = u["id"]; return {"token": t}
    if token not in TOKENS: raise ApiError("请先登录", 401)
    with db() as c:
        if path == "/api/password" and method == "POST":
            if len(str(body.get("password", ""))) < 6: raise ApiError("新密码至少 6 位")
            s = secrets.token_hex(8)
            c.execute("UPDATE users SET salt=?,pwd=? WHERE id=?", (s, hp(body["password"], s), TOKENS[token])); return {"ok": True}
        m = re.fullmatch(r"/api/(students|courses)(?:/(\d+))?", path)
        if m:
            kind, id = m.group(1), m.group(2) and int(m.group(2))
            if method == "GET" and not id: return list_items(c, kind, q)
            if method == "POST" and not id: return save_item(c, kind, body)
            if method == "PUT" and id: return save_item(c, kind, body, id)
            if method == "DELETE" and id: return delete_item(c, kind, id)
        if path == "/api/scores" and method == "GET": return get_scores(c, q)
        if path == "/api/scores" and method == "POST": return save_scores(c, body)
    raise ApiError("接口不存在", 404)


class H(BaseHTTPRequestHandler):
    def handle_any(self):
        u = urlparse(self.path)
        if self.command == "GET" and not u.path.startswith("/api"):
            data = (BASE / "static" / "index.html").read_bytes()
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
            out, code = route(self.command, u.path, parse_qs(u.query), body, self.headers.get("Authorization", "")), 200
        except ApiError as e: out, code = {"error": e.msg}, e.code
        except json.JSONDecodeError: out, code = {"error": "请求格式错误"}, 400
        except Exception as e: out, code = {"error": f"服务器错误：{e}"}, 500
        data = json.dumps(out, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
    do_GET = do_POST = do_PUT = do_DELETE = handle_any
    def log_message(self, *a): pass


if __name__ == "__main__":
    init(); port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"成绩录入系统已启动： http://localhost:{port}  （默认账号 admin / admin123，Ctrl+C 退出）")
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
