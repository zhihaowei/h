# 成绩录入系统

零依赖：只需 Python 3.8+（内置 SQLite），无需 pip install。

## 运行
- Windows：双击 `start.bat`；macOS / Linux：`./start.sh`（或 `python3 server.py`）
- 浏览器打开 http://localhost:8000 ，默认账号 `admin` / `admin123`（登录后请点左下角“修改密码”）
- 换端口：`python3 server.py 9000`
- IDE：用 PyCharm（或装了 Python 插件的 IDEA）打开本文件夹，右键 `server.py` 运行

## 功能
- 成绩录入：按课程 + 学期、可按班级筛选，表格内逐个输入，回车跳到下一位；实时显示平均分、最高/最低、及格率、分数段分布；留空即清除该成绩；可导出 CSV（Excel 可直接打开）
- 学生成绩单：学分加权平均分、已获学分（≥60 分）、各学期各课程成绩
- 学生管理、课程管理：增删改查与搜索（删除时会同时删除其成绩）
- 管理员登录与改密码；成绩校验范围 0–100，同一学生同一课程同一学期只保留一条

## 文件
`server.py` 后端与 REST API　`static/index.html` 前端　`grades.db` 首次运行自动生成（含示例数据，删除即可重置）
服务仅监听 127.0.0.1；需局域网访问时把 server.py 末尾的 "127.0.0.1" 改为 "0.0.0.0"
