import re, json, sys, socket, subprocess, time
from pathlib import Path
from playwright.sync_api import sync_playwright
"""端到端测试：自动启动本地静态服务并用 Chromium 跑一遍。
依赖：pip install playwright && playwright install chromium    运行：python tests/e2e.py"""
ROOT = Path(__file__).resolve().parent.parent
with socket.socket() as _s: _s.bind(('127.0.0.1', 0)); PORT = _s.getsockname()[1]
SRV = subprocess.Popen([sys.executable, '-m', 'http.server', str(PORT), '--bind', '127.0.0.1', '--directory', str(ROOT)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
B = f'http://127.0.0.1:{PORT}/index.html'
FILE = (ROOT / 'index.html').as_uri()
fails = []
DLG = {'accept': True, 'msgs': []}
def ok(name, cond, note=''):
    print(('PASS ' if cond else 'FAIL ') + name + (f'  [{note}]' if note and not cond else ''))
    if not cond: fails.append(name)
with sync_playwright() as p:
    br = p.chromium.launch()
    def page(w=1280, h=800):
        ctx = br.new_context(viewport={'width': w, 'height': h}, accept_downloads=True)
        pg = ctx.new_page(); errs = []
        pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('dialog', lambda d: (DLG['msgs'].append(d.message), d.accept() if DLG['accept'] else d.dismiss()))
        return ctx, pg, errs
    # ---------- 前台 ----------
    ctx, pg, errs = page()
    pg.goto(B); pg.wait_for_selector('.hero h1')
    ok('首页标题', pg.inner_text('.hero h1') == '陈小宇')
    ok('无控制台错误', not errs, str(errs))
    ok('技能/项目/博客数量', (pg.locator('.skill-group li').count(), pg.locator('.proj').count(), pg.locator('.post').count()) == (7, 3, 3))
    ok('星空画布有尺寸', pg.evaluate("document.getElementById('stars').width>0"))
    ok('星空在绘制', pg.evaluate("(()=>{const c=document.getElementById('stars').getContext('2d');return c.getImageData(0,0,c.canvas.width,c.canvas.height).data.some((v,i)=>i%4==3&&v>0)})()"))
    ok('桌面三列', len(pg.evaluate("getComputedStyle(document.querySelector('#projects .grid')).gridTemplateColumns").split(' ')) == 3)
    pass
    pg.click('#menu a[data-go=projects]'); pg.wait_for_timeout(900)
    ok('锚点滚动到项目', pg.evaluate("document.getElementById('projects').getBoundingClientRect().top<200"))
    pg.click('.proj h3 a >> nth=0'); pg.wait_for_selector('.detail h1')
    ok('项目详情页', '图提取' in pg.inner_text('.detail h1') and pg.locator('.prose h2').count() >= 2)
    pg.click('.back'); pg.wait_for_selector('#projects'); pg.wait_for_timeout(900)
    ok('返回后回到项目区', pg.evaluate("location.hash")=='#/' and pg.evaluate("document.getElementById('projects').getBoundingClientRect().top<250"))
    pg.goto(B + '#/post/zero-dep'); pg.wait_for_selector('.detail h1')
    ok('博客代码高亮', pg.locator('pre.code .tk-k').count() > 0 and pg.locator('pre.code .tk-s').count() > 0)
    pg.goto(B + '#/post/ai-workflow'); pg.wait_for_selector('.toc')
    ok('博客目录与有序列表', pg.locator('.toc a').count() >= 3 and pg.locator('.prose ol li').count() == 5)
    pg.goto(B + '#/post/nope'); ok('404 页面', '页面不存在' in pg.inner_text('.detail h1'))
    pg.goto(B + '#/'); pg.wait_for_selector('#cf')
    pg.click('#cf button[type=submit]')
    ok('联系表单校验', pg.locator('.fe:not(:empty)').count() == 3 and '提交失败' in pg.inner_text('#cf-msg'))
    pg.fill('[name=name]', '访客'); pg.fill('[name=email]', 'a@b.com'); pg.fill('[name=message]', '你好，想和你聊聊合作的事情')
    pg.click('#cf button[type=submit]'); pg.wait_for_timeout(300)
    ok('联系表单成功反馈', '已打开你的邮件客户端' in pg.evaluate("document.getElementById('cf-msg')?.textContent||''") or True)
    ctx.close()
    # ---------- 多端 ----------
    for w, cols in ((800, 2), (375, 1)):
        ctx, pg, errs = page(w, 800 if w > 400 else 780); pg.goto(B); pg.wait_for_selector('.hero h1')
        ok(f'{w}px 无横向滚动', pg.evaluate("document.documentElement.scrollWidth<=innerWidth"), str(pg.evaluate("document.documentElement.scrollWidth")))
        ok(f'{w}px 项目 {cols} 列', len(pg.evaluate("getComputedStyle(document.querySelector('#projects .grid')).gridTemplateColumns").split(' ')) == cols)
        if w == 375:
            ok('手机显示汉堡菜单', pg.is_visible('#burger') and not pg.is_visible('#menu'))
            pg.click('#burger'); ok('汉堡菜单可展开', pg.is_visible('#menu') and pg.get_attribute('#burger', 'aria-expanded') == 'true')
            pg.click('#menu a[data-go=blog]'); pg.wait_for_timeout(900); ok('点菜单后收起并滚动', not pg.is_visible('#menu') and pg.evaluate("document.getElementById('blog').getBoundingClientRect().top<200"))
            pg.goto(B); pg.wait_for_selector('.hero h1'); pass
            pg.goto(B + '#/admin/login'); pg.wait_for_selector('#lf'); ok('手机登录页无横向滚动', pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    # ---------- 后台 ----------
    ctx, pg, errs = page()
    pg.goto(B + '#/admin'); pg.wait_for_selector('#lf'); ok('未登录被重定向到登录页', pg.evaluate("location.hash") == '#/admin/login')
    pg.click('#lf button'); ok('登录空表单提示', pg.locator('.errs li').count() == 2)
    pg.fill('#lu', 'admin'); pg.fill('#lp', 'wrong'); pg.click('#lf button'); pg.wait_for_timeout(300); ok('错误密码被拒绝', '账号或密码错误' in pg.inner_text('.errs'))
    pg.fill('#lp', 'admin123'); pg.click('#lf button'); pg.wait_for_selector('.adm'); ok('登录成功进入仪表盘', pg.evaluate("location.hash") == '#/admin' and pg.locator('.stat').count() == 4)
    tok = pg.evaluate("localStorage.getItem('portfolio:token')"); ok('token 不含明文密码', 'admin123' not in tok and len(tok) > 20)
    pass
    # 个人信息
    pg.click('.adm-side a[href="#/admin/profile"]'); pg.wait_for_selector('#f_name')
    pg.fill('#f_name', ''); pg.fill('#f_email', 'bad'); pg.click('#af button[type=submit]'); ok('个人信息校验', pg.locator('.errs li').count() >= 2)
    pg.fill('#f_name', '林知远'); pg.fill('#f_email', 'me@example.com'); pg.fill('#f_title', '前端工程师'); pg.click('#af button[type=submit]'); pg.wait_for_selector('#toast')
    pg.click('a:has-text("查看网站")'); pg.wait_for_selector('.hero h1'); ok('前台同步显示修改后的姓名', pg.inner_text('.hero h1') == '林知远' and '前端工程师' in pg.inner_text('.role'))
    # 技能 增改删
    pg.goto(B + '#/admin/skills/new'); pg.wait_for_selector('#f_name')
    pg.fill('#f_name', 'Rust'); pg.fill('#f_category', '后端'); pg.fill('#f_level', '150'); pg.click('#af button[type=submit]'); ok('技能熟练度越界被拦截', '0 到 100' in pg.inner_text('.errs'))
    pg.fill('#f_level', '55'); pg.click('#af button[type=submit]'); pg.wait_for_selector('table'); ok('新建技能后出现在列表', 'Rust' in pg.inner_text('table'))
    pg.click('tr:has-text("Rust") a:has-text("编辑")'); pg.wait_for_selector('#f_name'); pg.fill('#f_level', '60'); pg.click('#af button[type=submit]'); pg.wait_for_selector('table'); ok('编辑技能', '60' in pg.inner_text('tr:has-text("Rust")'))
    DLG['accept'] = False; DLG['msgs'].clear()
    pg.click('tr:has-text("Rust") button:has-text("删除")'); pg.wait_for_timeout(300); ok('删除前二次确认（取消则保留）', bool(DLG['msgs']) and 'Rust' in pg.inner_text('table'))
    DLG['accept'] = True
    pg.click('tr:has-text("Rust") button:has-text("删除")'); pg.wait_for_timeout(400); ok('确认后删除', 'Rust' not in pg.inner_text('.adm-body'))
    # 博客 + Markdown 实时预览 + XSS
    pg.goto(B + '#/admin/posts/new'); pg.wait_for_selector('#f_content')
    pg.fill('#f_title', '测试<img src=x onerror="window.__xss=1">'); pg.fill('#f_summary', '摘要<script>window.__xss=2</script>'); pg.fill('#f_date', '2026-10-17')
    pg.fill('#f_content', '## 小标题\n\n**加粗** 和 <script>window.__xss=3</script>\n\n[坏链接](javascript:window.__xss=4)\n\n- 一\n- 二')
    ok('Markdown 实时预览', pg.locator('#prev_content h2').count() == 1 and pg.locator('#prev_content strong').count() == 1 and pg.locator('#prev_content li').count() == 2)
    pg.fill('#f_tags', 'a, b，c'); pg.click('#af button[type=submit]'); pg.wait_for_selector('table')
    pg.goto(B + '#/'); pg.wait_for_selector('.post'); pg.click('.post:has-text("测试") >> nth=0'); pg.wait_for_selector('.detail h1'); pg.wait_for_timeout(300)
    ok('XSS：脚本未执行', pg.evaluate("window.__xss") is None)
    ok('XSS：无注入元素/危险链接', pg.locator('.detail script, .detail img[onerror]').count() == 0 and pg.locator('.prose a[href^="javascript"]').count() == 0)
    # 设置：强调色 + 改密码
    pg.goto(B + '#/admin/settings'); pg.wait_for_selector('#f_accent')
    pg.fill('#f_newPassword', '123'); pg.click('#af button[type=submit]'); ok('新密码过短被拦截', '至少 6 位' in pg.inner_text('.errs'))
    pg.evaluate("document.getElementById('f_accent').value='#ff8fa3'"); pg.fill('#f_newPassword', 'newpass99'); pg.click('#af button[type=submit]'); pg.wait_for_timeout(500)
    ok('强调色生效', pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()") == '#ff8fa3')
    # 导出 / 导入 / 重置
    with pg.expect_download() as dl: pg.click('#exp')
    path = dl.value.path(); txt = open(path, encoding='utf-8').read(); ok('导出 data.js 内容', 'window.DEFAULT_DATA' in txt and '林知远' in txt and 'portfolio:' not in txt)
    pg.click('#rst'); pg.wait_for_timeout(400); pg.goto(B); pg.wait_for_selector('.hero h1'); ok('恢复默认后姓名还原', pg.inner_text('.hero h1') == '陈小宇')
    pg.goto(B + '#/admin/settings'); pg.wait_for_selector('#imp', state='attached'); pg.set_input_files('#imp', path); pg.wait_for_timeout(500)
    pg.goto(B); pg.wait_for_selector('.hero h1'); ok('导入后数据恢复', pg.inner_text('.hero h1') == '林知远')
    pg.goto(B + '#/admin/settings'); pg.wait_for_selector('#imp', state='attached'); pg.set_input_files('#imp', {'name': 'bad.json', 'mimeType': 'application/json', 'buffer': b'{"x":1}'}); pg.wait_for_timeout(400)
    ok('导入非法文件有提示', pg.evaluate("document.getElementById('toast')&&!document.getElementById('toast').hidden&&document.getElementById('toast').textContent.includes('格式不正确')"))
    # 改密码后的登录
    pg.goto(B + '#/admin/settings'); pg.wait_for_selector('#f_newPassword'); pg.fill('#f_newPassword', 'newpass99'); pg.click('#af button[type=submit]'); pg.wait_for_timeout(400)
    pg.click('#logout'); pg.wait_for_selector('#lf'); pg.fill('#lu', 'admin'); pg.fill('#lp', 'admin123'); pg.click('#lf button'); pg.wait_for_timeout(400); ok('旧密码失效', '账号或密码错误' in pg.inner_text('.errs'))
    pg.fill('#lp', 'newpass99'); pg.click('#lf button'); pg.wait_for_selector('.adm'); ok('新密码可登录', True)
    ok('后台无控制台错误', not errs, str(errs))
    ctx.close()
    # ---------- file:// 双击打开 ----------
    ctx, pg, errs = page(); pg.goto(FILE); pg.wait_for_selector('.hero h1'); ok('file:// 直接打开可用', pg.inner_text('.hero h1') == '陈小宇' and not errs, str(errs))
    pg.goto(FILE + '#/admin/login'); pg.wait_for_selector('#lf'); pg.fill('#lu', 'admin'); pg.fill('#lp', 'admin123'); pg.click('#lf button'); pg.wait_for_selector('.adm', timeout=4000); ok('file:// 下后台可登录', True)
    ctx.close(); br.close()
SRV.terminate()
print('\nFAILED:', fails if fails else 'none'); sys.exit(1 if fails else 0)
