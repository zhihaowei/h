# AGENTS.md

## 项目概述
个人展示网站：前台（首页、项目、博客、联系）+ 后台（/#/admin，管理个人信息、技能、项目、博客、站点设置）。深色星空主题，纯静态，无构建步骤，部署在 Cloudflare Pages / Vercel。详见 `PRD.md` 和 `TECH_DESIGN.md`。

## 开发规范
- **不引入构建工具和第三方库**（不用 npm、不用 CDN）。需要新能力先用原生 API 实现。
- 所有脚本挂在全局命名空间 `window.PF` 下，在 `index.html` 中按顺序加载：`data → util → md → store → stars → front → admin → app`。新增文件要放在依赖它的文件之前。
- **数据读写只能通过 `PF.Api`**（`js/store.js`），页面代码不得直接读写 `localStorage`。
- **所有用户可编辑的数据输出到 HTML 前必须经过 `PF.U.esc()`**；链接 / 图片地址必须经过 `PF.U.safeUrl()`；Markdown 只能用 `PF.Md.render()`。禁止使用 `eval`，禁止把未转义内容拼进 `innerHTML`。
- 前台页面函数（`js/front.js`）只返回 HTML 字符串，不直接操作 DOM；DOM 事件绑定放在 `js/app.js`。
- 后台的删除操作必须二次确认，表单必须先 `PF.U.validate()` 再保存，并给出明确的成功 / 失败提示。
- 颜色、间距、圆角等使用 `css/style.css` 的 `:root` 变量，不要写死。新增 `[hidden]` 元素时注意 `display` 不要覆盖 `hidden` 属性。

## 代码风格
- 缩进 2 空格，使用单引号，语句末尾加分号。
- 变量和函数用 camelCase，CSS 类名用 kebab-case。
- 关键逻辑写中文注释，说明“为什么”而不是“做了什么”。
- 文件保持小而专注：一个文件只负责一件事。

## 测试要求
- 每完成一个功能，先在浏览器里手动验证，再运行端到端测试：
  ```
  pip install playwright && playwright install chromium
  python tests/e2e.py
  ```
- 测试必须覆盖：三种屏幕宽度（375 / 800 / 1280）无横向滚动、前台各页面渲染、后台登录与路由守卫、增删改与表单校验、删除二次确认、XSS 注入不执行、数据导出 / 导入 / 恢复默认。
- 测试通过后才能提交代码；修复 Bug 时先补一个能复现的测试。

## 注意事项
- 默认后台账号 `admin / admin123` 仅用于演示，上线前在「站点设置」修改。
- 后台修改只保存在当前浏览器，**不会**自动同步给其他访客；发布需导出 `data.js` 并替换 `js/data.js`。
- 前端登录守卫不是真正的安全机制，不要在站点里放任何敏感信息。
- 修改 `js/data.js` 的数据结构时，同步更新 `store.js` 的 `normalize()` 和 `TECH_DESIGN.md` 的数据模型。
- 提交信息用中文，说明改了什么、为什么改。
