# 个人展示网站（含后台）

深色星空主题的个人网站：个人介绍、技能、项目、博客、联系；后台可修改全部展示内容。纯静态，无需安装任何依赖。

## 本地预览
- 直接双击 `index.html`，或在本目录运行 `python3 -m http.server 8000` 后打开 http://localhost:8000
- 后台入口：页面底部「后台管理」，或网址后加 `#/admin`。演示账号 **admin / admin123**（登录后请到「站点设置」修改）
- 首先到后台把姓名、简介、邮箱、经历等改成你自己的信息，并按需增删项目和文章

## 修改内容并发布给所有人
后台修改保存在**当前浏览器**，只有你自己能看到。让所有访客看到的步骤：
1. 后台「仪表盘」或「站点设置」点击「导出 data.js」
2. 用下载的文件替换仓库里的 `js/data.js`
3. 提交并推送到 GitHub，Cloudflare / Vercel 会自动重新部署（约 1 分钟）

## 推送到 GitHub
在本目录运行（把用户名换成你的；先在 GitHub 新建一个空仓库，例如 `my-site`）：
```
git init
git add .
git commit -m "个人网站初始版本"
git branch -M main
git remote add origin https://github.com/你的用户名/my-site.git
git push -u origin main
```
没有安装 Git 的话，也可以在仓库页面用「uploading an existing file」把本目录里的**全部内容**拖进去（`index.html` 必须在仓库根目录）。

## 部署方式一：Cloudflare Pages（推荐）
1. 登录 Cloudflare，左侧进入「计算 → Workers 和 Pages」，点右上角「创建应用程序」。
2. 选择「导入现有 Git 存储库」，授权 GitHub 并选择刚才的仓库。
3. 生产分支填 `main`；**框架预设选「无」，构建命令留空，构建输出目录留空（或填 `/`）**。
4. 点「保存并部署」，等待完成后，在项目详情里能看到访问地址，形如 `https://项目名.pages.dev`。
（界面文字可能略有出入，以实际页面为准。之后每次推送代码都会自动重新部署。）

## 部署方式二：Vercel
1. 用 GitHub 登录 Vercel，注册时选择 Hobby（免费个人方案）。
2. 点「Add New → Project」，授权 GitHub，选择仓库，点 Import。
3. **Application Preset 选 `Other`，Root Directory 保持 `./`，不要填构建命令**，点 Deploy。
4. 部署完成后得到形如 `https://项目名.vercel.app` 的地址。如果打开是 404，到项目 Settings → Build and Output Settings，把 Output Directory 设为 `.` 后重新部署。

## 作业提交清单
| 要提交的 | 怎么做 |
|---|---|
| 03 PRD / TECH_DESIGN / AGENTS 三个文档内容的截图 | 在 GitHub 仓库里分别打开 `PRD.md`、`TECH_DESIGN.md`、`AGENTS.md`（渲染后的页面最清晰），各截一张；或用编辑器打开后截图 |
| 04 部署成功后的展示页面截图 | 打开线上网址，截前台首页（带地址栏）；再登录线上后台，截一张「后台修改个人信息」的页面，并截修改后前台显示变化的页面，证明“有后台、可修改” |
| 05 域名地址 | 填 Cloudflare 的 `https://….pages.dev` 或 Vercel 的 `https://….vercel.app` |

## 测试
```
pip install playwright && playwright install chromium
python tests/e2e.py
```
