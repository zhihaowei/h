# 技术设计文档（Tech Design）

## 一、技术栈选择
| 层 | 选择 | 理由 |
|---|---|---|
| 前端 | 原生 HTML + CSS + JavaScript，**无构建工具** | 内容型网站不需要框架；双击就能预览，部署时不需要构建，出错面最小 |
| 路由 | hash 路由（`#/project/xxx`、`#/admin/...`） | 静态托管无需配置重写规则，Cloudflare Pages / Vercel 开箱即用 |
| 后端 | 暂无；数据访问统一封装在 `PF.Api`（全部 async） | 先跑通完整产品，以后换真实后端只改 `store.js` 一个文件 |
| 数据存储 | `js/data.js` 提供默认数据 + 浏览器 `localStorage` 保存后台修改 | 无需数据库；修改可导出为 `data.js` 提交到仓库发布 |
| 部署 | GitHub + Cloudflare Pages（或 Vercel） | 免费、自带 CDN，推送代码自动重新部署 |

## 二、项目结构
```
index.html          页面外壳（画布 + #app 容器 + 脚本）
css/style.css       前台与后台全部样式（设计变量在 :root）
js/data.js          默认数据（站点内容）
js/util.js          转义、安全链接、表单校验
js/md.js            Markdown 渲染 + 代码高亮 + 目录
js/store.js         数据层 PF.Api + 登录 PF.Auth
js/stars.js         星空背景
js/front.js         前台页面（返回 HTML 字符串）
js/admin.js         后台页面与路由守卫
js/app.js           路由、前台交互
tests/e2e.py        端到端测试（Playwright）
PRD.md  TECH_DESIGN.md  AGENTS.md  README.md
```

## 三、数据模型
```
profile    { name, title, tagline, avatarText, about, email, location, resumeUrl, socials:[{label,url}] }
experience { id, org, role, start, end, desc }
education  { id, school, degree, start, end }
skills     { id, category, name, icon, level(0-100) }
projects   { id, title, summary, tags[], date, cover, link, repo, content(Markdown) }
posts      { id, title, summary, tags[], date, content(Markdown) }
settings   { siteTitle, footer, accent, adminUser, passHash }
```
`localStorage` 键：`portfolio:data:v1`（全部数据）、`portfolio:token`（登录态）、`portfolio:dirty`（是否有未发布修改）。

## 四、关键技术点
1. **数据发布流程**：后台修改只保存在当前浏览器，访客看不到。要让所有人看到：后台「导出 data.js」→ 替换仓库中的 `js/data.js` → 提交推送 → 自动重新部署。
2. **XSS 防护**：所有用户数据渲染前一律转义；Markdown 先转义再解析；链接只允许 http(s)、mailto 和相对路径，拒绝 `javascript:`。
3. **登录与路由守卫**：密码用 SHA-256 哈希比对（不明文存储），登录态只存随机 token（7 天过期），进入 `/admin` 前检查。**这是纯前端守卫，只用于演示，不是真正的安全措施**——因为数据只存在访客自己的浏览器里，访客改动不会影响别人；接入真实后端后必须改为服务端校验。
4. **星空背景**：Canvas 粒子 + 正弦闪烁 + 指针/滚动视差；粒子数随屏幕面积计算，手机更少；页面隐藏时暂停；`prefers-reduced-motion` 下只绘制静态画面。
5. **Markdown 渲染**：自实现轻量解析器，支持标题、列表、引用、代码块（关键字 / 字符串 / 注释 / 数字高亮）、链接、图片，并生成目录。
6. **留言表单**：静态站点没有后端，校验通过后用 `mailto:` 打开邮件客户端发送，并给出明确反馈。
7. **响应式**：CSS 变量 + Grid；断点 640 / 1024；手机导航折叠为汉堡菜单；后台侧边栏在手机上变为顶部横向菜单。

## 五、后续演进
接入 Cloudflare Workers + D1（或 Supabase）作为真实后端：后台修改直接写库、所有访客立即可见；留言表单真正投递；登录改为服务端校验。
