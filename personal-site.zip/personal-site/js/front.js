/* 前台页面：所有函数只返回 HTML 字符串（用户数据一律经 esc 转义），便于测试 */
(function () {
  const PF = (window.PF = window.PF || {});
  const { esc, safeUrl } = PF.U;
  const enc = encodeURIComponent;
  const hue = (s) => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
  const tags = (a) => (a && a.length ? `<ul class="tags">${a.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : '');
  const byDate = (a) => [...a].sort((x, y) => String(y.date).localeCompare(String(x.date)));
  const cover = (p) => (safeUrl(p.cover) && !/^mailto:/i.test(p.cover)
    ? `<img src="${esc(p.cover)}" alt="${esc(p.title)}" loading="lazy">`
    : `<div class="cover-gen" style="--h:${hue(p.title)}"><span>${esc(String(p.title).slice(0, 2))}</span></div>`);
  const sec = (id, title, inner) => `<section class="sec" id="${id}"><div class="wrap"><h2 class="sec-h">${title}</h2>${inner}</div></section>`;
  const link = (u, t, extra) => (safeUrl(u) && !/^mailto:/i.test(u) ? `<a class="btn ghost sm" href="${esc(u)}" target="_blank" rel="noopener noreferrer"${extra || ''}>${t}</a>` : '');

  const NAV = [['about', '关于'], ['skills', '技能'], ['projects', '项目'], ['blog', '博客'], ['contact', '联系']];
  function nav(d) {
    return `<header class="nav" id="nav"><div class="wrap nav-in">
      <a class="brand" href="#/" data-go="top" aria-label="回到顶部"><span>${esc(d.profile.name)}</span></a>
      <button class="burger" id="burger" aria-label="打开菜单" aria-expanded="false" aria-controls="menu"><i></i><i></i><i></i></button>
      <nav class="menu" id="menu" aria-label="主导航">${NAV.map(([id, t]) => `<a href="#/" data-go="${id}">${t}</a>`).join('')}</nav>
    </div></header>`;
  }
  function footer(d) {
    return `<footer class="foot"><div class="wrap foot-in"><p>${esc(d.settings.footer)}</p><a href="#/admin">后台管理</a></div></footer>`;
  }

  function home(d) {
    const p = d.profile;
    const hero = `<section class="hero" id="top"><div class="wrap hero-in">
      <div class="avatar" aria-hidden="true">${esc(p.avatarText || p.name.slice(0, 1))}</div>
      <h1>${esc(p.name)}</h1><p class="role">${esc(p.title)}</p><p class="tagline">${esc(p.tagline)}</p>
      <div class="cta"><a class="btn" href="#/" data-go="projects">看项目</a>
        ${safeUrl(p.resumeUrl) && !/^mailto:/i.test(p.resumeUrl) ? `<a class="btn ghost" href="${esc(p.resumeUrl)}" download>下载简历</a>` : ''}
        <a class="btn ghost" href="#/" data-go="contact">联系我</a></div></div></section>`;

    const paras = String(p.about || '').split(/\n{2,}/).filter(Boolean).map((t) => `<p>${esc(t)}</p>`).join('');
    const exp = d.experience.map((e) => `<li><div class="tl-h"><b>${esc(e.role)}</b><span>${esc(e.org)}</span></div><time>${esc(e.start)} – ${esc(e.end)}</time>${e.desc ? `<p>${esc(e.desc)}</p>` : ''}</li>`).join('');
    const edu = d.education.map((e) => `<li><div class="tl-h"><b>${esc(e.school)}</b><span>${esc(e.degree)}</span></div><time>${esc(e.start)} – ${esc(e.end)}</time></li>`).join('');
    const about = sec('about', '关于我', `<div class="about"><div class="prose">${paras}</div>
      <div class="tl-wrap">${exp ? `<h3>经历</h3><ol class="tl">${exp}</ol>` : ''}${edu ? `<h3>教育</h3><ol class="tl">${edu}</ol>` : ''}</div></div>`);

    const groups = [];
    d.skills.forEach((s) => { let g = groups.find((x) => x.c === s.category); if (!g) groups.push((g = { c: s.category, items: [] })); g.items.push(s); });
    const skills = sec('skills', '技能', `<div class="grid cols">${groups.map((g) => `<div class="card skill-group"><h3>${esc(g.c)}</h3><ul>${g.items.map((s) => {
      const lv = Math.max(0, Math.min(100, +s.level || 0));
      return `<li><span class="sk-ic" aria-hidden="true">${esc(s.icon || s.name.slice(0, 1))}</span><span class="sk-n">${esc(s.name)}</span>
        <span class="sk-bar" role="progressbar" aria-label="${esc(s.name)} 熟练度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${lv}"><i style="width:${lv}%"></i></span><span class="sk-v">${lv}%</span></li>`; }).join('')}</ul></div>`).join('')}</div>`);

    const projects = sec('projects', '项目', d.projects.length ? `<div class="grid cols">${byDate(d.projects).map((x) => `<article class="card proj">
      <a class="proj-cover" href="#/project/${enc(x.id)}" tabindex="-1" aria-hidden="true">${cover(x)}</a>
      <div class="proj-b"><h3><a href="#/project/${enc(x.id)}">${esc(x.title)}</a></h3><p>${esc(x.summary)}</p>${tags(x.tags)}</div></article>`).join('')}</div>` : '<p class="empty">暂无项目。</p>');

    const blog = sec('blog', '博客', d.posts.length ? `<div class="posts">${byDate(d.posts).map((x) => `<a class="card post" href="#/post/${enc(x.id)}">
      <time>${esc(x.date)}</time><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p>${tags(x.tags)}</a>`).join('')}</div>` : '<p class="empty">暂无文章。</p>');

    const socials = (d.profile.socials || []).map((s) => link(s.url, esc(s.label))).join('');
    const contact = sec('contact', '联系', `<div class="contact">
      <div class="contact-info"><p>有想法或合作，欢迎联系我。</p>
        <p><button class="btn" type="button" data-copy="${esc(p.email)}">复制邮箱：${esc(p.email)}</button></p>
        ${p.location ? `<p class="mute">所在地：${esc(p.location)}</p>` : ''}<div class="socials">${socials}</div></div>
      <form class="card form" id="cf" novalidate>
        <label>姓名<input name="name" autocomplete="name"><small class="fe" data-for="name"></small></label>
        <label>邮箱<input name="email" type="email" autocomplete="email"><small class="fe" data-for="email"></small></label>
        <label>留言<textarea name="message" rows="5"></textarea><small class="fe" data-for="message"></small></label>
        <button class="btn" type="submit">发送留言</button><p id="cf-msg" role="status" aria-live="polite"></p></form></div>`);
    return hero + about + skills + projects + blog + contact;
  }

  function toc(t) { return t.length > 1 ? `<aside class="toc" aria-label="目录"><b>目录</b>${t.map((x) => `<a class="l${x.level}" href="#/" data-h="${esc(x.id)}">${esc(x.text)}</a>`).join('')}</aside>` : ''; }
  function project(p) {
    const r = PF.Md.render(p.content);
    return `<article class="wrap detail"><a class="back" href="#/" data-go="projects">返回项目列表</a>
      <h1>${esc(p.title)}</h1><p class="meta">${esc(p.date)}</p><p class="lead">${esc(p.summary)}</p>${tags(p.tags)}
      <div class="links">${link(p.link, '访问项目')}${link(p.repo, '源码仓库')}</div>
      <div class="detail-body">${toc(r.toc)}<div class="prose">${r.html}</div></div></article>`;
  }
  function post(p) {
    const r = PF.Md.render(p.content);
    return `<article class="wrap detail"><a class="back" href="#/" data-go="blog">返回博客列表</a>
      <h1>${esc(p.title)}</h1><p class="meta">${esc(p.date)}</p>${tags(p.tags)}
      <div class="detail-body">${toc(r.toc)}<div class="prose">${r.html}</div></div></article>`;
  }
  const notFound = () => `<div class="wrap detail"><h1>页面不存在</h1><p><a class="back" href="#/">回到首页</a></p></div>`;

  PF.Front = { nav, footer, home, project, post, notFound };
  if (typeof module !== 'undefined') module.exports = PF.Front;
})();
