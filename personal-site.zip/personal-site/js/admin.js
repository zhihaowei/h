/* 后台管理：/admin 路由，独立布局（侧边栏 + 顶栏）。所有数据读写通过 PF.Api，删除前二次确认，表单用 PF.U.validate 校验 */
(function () {
  const PF = (window.PF = window.PF || {});
  const { esc } = PF.U, A = PF.Api;

  // ---- 各类内容的字段定义（也决定列表显示哪些列） ----
  const COLL = {
    skills: { title: '技能', cols: [['name', '名称'], ['category', '分类'], ['level', '熟练度']], fields: [
      { k: 'name', l: '名称', t: 'text', req: 1, max: 30 }, { k: 'category', l: '分类', t: 'text', req: 1, max: 20 },
      { k: 'icon', l: '图标（emoji 或 1-2 个字）', t: 'text', max: 4 }, { k: 'level', l: '熟练度（0-100）', t: 'number', req: 1, min: 0, max: 100 }] },
    projects: { title: '项目', cols: [['title', '标题'], ['date', '日期'], ['tags', '标签']], fields: [
      { k: 'title', l: '标题', t: 'text', req: 1, max: 60 }, { k: 'summary', l: '摘要', t: 'textarea', req: 1, max: 200, rows: 3 },
      { k: 'tags', l: '标签（逗号分隔）', t: 'tags' }, { k: 'date', l: '日期', t: 'date', req: 1 },
      { k: 'cover', l: '封面图链接（留空自动生成）', t: 'url' }, { k: 'link', l: '项目链接', t: 'url' }, { k: 'repo', l: '源码链接', t: 'url' },
      { k: 'content', l: '详情（Markdown）', t: 'markdown', req: 1 }] },
    posts: { title: '博客', cols: [['title', '标题'], ['date', '日期'], ['tags', '标签']], fields: [
      { k: 'title', l: '标题', t: 'text', req: 1, max: 80 }, { k: 'summary', l: '摘要', t: 'textarea', req: 1, max: 200, rows: 3 },
      { k: 'tags', l: '标签（逗号分隔）', t: 'tags' }, { k: 'date', l: '日期', t: 'date', req: 1 }, { k: 'content', l: '正文（Markdown）', t: 'markdown', req: 1 }] },
    experience: { title: '经历', cols: [['role', '职位'], ['org', '单位'], ['start', '开始']], fields: [
      { k: 'role', l: '职位', t: 'text', req: 1, max: 40 }, { k: 'org', l: '单位', t: 'text', req: 1, max: 40 },
      { k: 'start', l: '开始（如 2026-09）', t: 'text', req: 1, max: 12 }, { k: 'end', l: '结束（如 至今）', t: 'text', req: 1, max: 12 },
      { k: 'desc', l: '描述', t: 'textarea', max: 300, rows: 3 }] },
    education: { title: '教育', cols: [['school', '学校'], ['degree', '专业/学位'], ['start', '开始']], fields: [
      { k: 'school', l: '学校', t: 'text', req: 1, max: 40 }, { k: 'degree', l: '专业/学位', t: 'text', req: 1, max: 40 },
      { k: 'start', l: '开始年份', t: 'text', req: 1, max: 12 }, { k: 'end', l: '结束年份', t: 'text', req: 1, max: 12 }] }
  };
  const PROFILE = [
    { k: 'name', l: '姓名', t: 'text', req: 1, max: 30 }, { k: 'title', l: '职位 / 身份', t: 'text', req: 1, max: 50 },
    { k: 'tagline', l: '一句话介绍', t: 'text', max: 80 }, { k: 'avatarText', l: '头像文字（1-2 个字）', t: 'text', max: 2 },
    { k: 'about', l: '个人简介（空一行分段）', t: 'textarea', rows: 7, max: 1200 }, { k: 'email', l: '联系邮箱', t: 'email', req: 1 },
    { k: 'location', l: '所在地', t: 'text', max: 30 }, { k: 'resumeUrl', l: '简历下载链接（留空则不显示按钮）', t: 'url' },
    { k: 'socials', l: '社交链接（每行一个：名称 | 链接）', t: 'socials' }];
  const SETTINGS = [
    { k: 'siteTitle', l: '网站标题', t: 'text', req: 1, max: 40 }, { k: 'footer', l: '页脚文字', t: 'text', max: 80 },
    { k: 'accent', l: '强调色', t: 'color', req: 1 }, { k: 'adminUser', l: '后台账号', t: 'text', req: 1, max: 20 },
    { k: 'newPassword', l: '新密码（不修改请留空，至少 6 位）', t: 'password', min: 6 }];
  const MENU = [['', '仪表盘'], ['profile', '个人信息'], ['experience', '经历'], ['education', '教育'], ['skills', '技能'], ['projects', '项目'], ['posts', '博客'], ['settings', '站点设置']];

  // ---- 纯函数：转换（可在 Node 测试） ----
  const tagsToArr = (s) => String(s).split(/[,，]/).map((x) => x.trim()).filter(Boolean);
  const socialsToText = (a) => (a || []).map((s) => s.label + ' | ' + s.url).join('\n');
  const textToSocials = (t) => String(t).split('\n').map((l) => l.trim()).filter(Boolean).map((l) => { const i = l.indexOf('|'); return i < 0 ? { label: l, url: '' } : { label: l.slice(0, i).trim(), url: l.slice(i + 1).trim() }; });
  function checkSocials(a) { return a.filter((s) => !s.label || !/^https?:\/\//i.test(s.url)).map((s) => `社交链接“${s.label || '?'}”格式不对，应为：名称 | https://…`); }

  // ---- 表单渲染 / 读取 ----
  function fieldHtml(f, val) {
    const id = 'f_' + f.k, req = f.req ? ' <i class="req">*</i>' : '';
    let v = val == null ? '' : val;
    if (f.t === 'tags') v = (val || []).join(', ');
    if (f.t === 'socials') v = socialsToText(val);
    const lab = `<label for="${id}">${esc(f.l)}${req}</label>`;
    if (f.t === 'markdown') return `<div class="fld full">${lab}<div class="md-split"><textarea id="${id}" name="${f.k}" rows="18" spellcheck="false">${esc(v)}</textarea><div class="md-prev prose" id="prev_${f.k}" aria-label="实时预览"></div></div></div>`;
    if (f.t === 'textarea' || f.t === 'socials') return `<div class="fld full">${lab}<textarea id="${id}" name="${f.k}" rows="${f.rows || 4}">${esc(v)}</textarea></div>`;
    const type = { number: 'number', color: 'color', password: 'password', email: 'email' }[f.t] || 'text';
    return `<div class="fld">${lab}<input id="${id}" name="${f.k}" type="${type}" value="${esc(v)}"${f.t === 'date' ? ' placeholder="YYYY-MM-DD"' : ''}${f.t === 'password' ? ' autocomplete="new-password"' : ''}></div>`;
  }
  function readForm(fields, root) {
    const o = {};
    for (const f of fields) {
      const el = root.querySelector(`[name="${f.k}"]`); let v = el ? el.value : '';
      if (f.t === 'number') o[f.k] = v.trim() === '' ? null : Number(v);
      else if (f.t === 'tags') o[f.k] = tagsToArr(v);
      else if (f.t === 'socials') o[f.k] = textToSocials(v);
      else o[f.k] = f.t === 'markdown' || f.t === 'password' ? v : v.trim();
    }
    return o;
  }
  const showErrs = (root, errs) => { const b = root.querySelector('.errs'); b.hidden = !errs.length; b.innerHTML = errs.length ? '<b>请修改后再保存：</b><ul>' + errs.map((e) => `<li>${esc(e)}</li>`).join('') + '</ul>' : ''; if (errs.length) b.scrollIntoView({ block: 'nearest' }); };
  function bindPreview(root) {
    root.querySelectorAll('.md-split textarea').forEach((ta) => {
      const pv = root.querySelector('#prev_' + ta.name), up = () => (pv.innerHTML = PF.Md.render(ta.value).html);
      ta.addEventListener('input', up); up();
    });
  }
  let toastT;
  function toast(msg, bad) {
    let t = document.getElementById('toast');
    if (!t) { t = document.createElement('div'); t.id = 'toast'; document.body.appendChild(t); }
    t.textContent = msg; t.className = bad ? 'bad' : ''; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => (t.hidden = true), 2600);
  }
  function download(name, text) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'text/javascript;charset=utf-8' })); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  // ---- 布局 ----
  function shell(active, title, inner, actions) {
    return `<div class="adm"><aside class="adm-side"><div class="adm-brand">后台管理</div><nav aria-label="后台导航">${MENU.map(([k, t]) => `<a href="#/admin${k ? '/' + k : ''}" class="${active === k ? 'on' : ''}"${active === k ? ' aria-current="page"' : ''}>${t}</a>`).join('')}</nav></aside>
      <div class="adm-main"><header class="adm-top"><h1>${esc(title)}</h1><div class="adm-act">${actions || ''}<a class="btn ghost sm" href="#/">查看网站</a><button class="btn ghost sm" id="logout" type="button">退出登录</button></div></header>
      <div class="adm-body">${inner}</div></div></div>`;
  }

  // ---- 页面 ----
  function loginPage(root) {
    root.innerHTML = `<div class="login"><form class="card" id="lf" novalidate><h1>后台登录</h1>
      <div class="fld"><label for="lu">账号</label><input id="lu" name="u" autocomplete="username"></div>
      <div class="fld"><label for="lp">密码</label><input id="lp" name="p" type="password" autocomplete="current-password"></div>
      <p class="errs" hidden></p><button class="btn" type="submit">登录</button>
      <p class="mute small">演示默认账号：admin / admin123，登录后请在“站点设置”修改。<a href="#/">返回网站</a></p></form></div>`;
    root.querySelector('#lf').onsubmit = async (e) => {
      e.preventDefault(); const f = e.target, errs = [];
      if (!f.u.value.trim()) errs.push('请输入账号'); if (!f.p.value) errs.push('请输入密码');
      if (errs.length) return showErrs(root, errs);
      try { if (await PF.Auth.login(f.u.value.trim(), f.p.value)) location.hash = '#/admin'; else showErrs(root, ['账号或密码错误']); }
      catch (err) { showErrs(root, [err.message]); }
    };
  }
  function dashboard(root, d) {
    const n = (a) => `<div class="stat"><b>${a.length}</b><span>`;
    const dirty = A.isDirty();
    root.innerHTML = shell('', '仪表盘', `<div class="stats">${n(d.skills)}技能</span></div>${n(d.projects)}项目</span></div>${n(d.posts)}文章</span></div>${n(d.experience.concat(d.education))}经历与教育</span></div></div>
      <section class="card pad"><h2>发布修改</h2><p>后台的修改保存在<b>当前浏览器</b>里，只有你自己能看到。想让所有访客都看到：点击下面的按钮导出 <code>data.js</code>，用它替换仓库里的 <code>js/data.js</code>，提交并推送，网站会自动重新部署。</p>
      <p class="${dirty ? 'tag-warn' : 'tag-ok'}">${dirty ? '当前浏览器里有尚未发布的修改' : '当前显示的是网站默认数据'}</p>
      <p><button class="btn" id="exp" type="button">导出 data.js</button></p></section>`);
    root.querySelector('#exp').onclick = () => download('data.js', A.exportJs());
  }
  function formPage(root, active, title, fields, values, onSave, cancelHref) {
    root.innerHTML = shell(active, title, `<form class="card pad aform" id="af" novalidate><p class="errs" hidden></p><div class="fgrid">${fields.map((f) => fieldHtml(f, values[f.k])).join('')}</div>
      <div class="form-act"><button class="btn" type="submit">保存</button>${cancelHref ? `<a class="btn ghost" href="${cancelHref}">取消</a>` : ''}</div></form>`);
    const form = root.querySelector('#af'); bindPreview(root);
    form.onsubmit = async (e) => {
      e.preventDefault(); const v = readForm(fields, form), errs = PF.U.validate(fields, v);
      if (v.socials) errs.push(...checkSocials(v.socials));
      if (errs.length) return showErrs(root, errs);
      try { await onSave(v); } catch (err) { showErrs(root, [err.message]); }
    };
  }
  function listPage(root, key, d) {
    const c = COLL[key], items = d[key], cell = (it, k) => (Array.isArray(it[k]) ? it[k].join('、') : it[k] == null ? '' : it[k]);
    root.innerHTML = shell(key, c.title + '管理', items.length ? `<div class="card tbl-wrap"><table><thead><tr>${c.cols.map(([, l]) => `<th>${l}</th>`).join('')}<th>操作</th></tr></thead><tbody>${items.map((it) => `<tr>${c.cols.map(([k]) => `<td>${esc(cell(it, k))}</td>`).join('')}<td class="ops"><a class="btn ghost sm" href="#/admin/${key}/edit/${encodeURIComponent(it.id)}">编辑</a><button class="btn danger sm" data-del="${esc(it.id)}" type="button">删除</button></td></tr>`).join('')}</tbody></table></div>` : `<div class="card pad empty">还没有${c.title}，点击右上角“新建”添加第一条。</div>`,
      `<a class="btn sm" href="#/admin/${key}/new">新建${c.title}</a>`);
    root.querySelectorAll('[data-del]').forEach((b) => (b.onclick = async () => {
      const it = items.find((x) => x.id === b.dataset.del), name = it.title || it.name || it.role || it.school || '这条记录';
      if (!confirm(`确定删除“${name}”吗？此操作不能撤销。`)) return;                        // 二次确认
      await A.remove(key, it.id); toast('已删除'); render('/admin/' + key, root, await A.all());
    }));
  }
  function settingsPage(root, d) {
    root.innerHTML = shell('settings', '站点设置', `<form class="card pad aform" id="af" novalidate><p class="errs" hidden></p><div class="fgrid">${SETTINGS.map((f) => fieldHtml(f, d.settings[f.k])).join('')}</div><div class="form-act"><button class="btn" type="submit">保存设置</button></div></form>
      <section class="card pad"><h2>数据管理</h2><p>导出 / 导入全部网站数据，或恢复为网站默认数据。</p><div class="form-act">
      <button class="btn ghost" id="exp" type="button">导出 data.js</button><label class="btn ghost filebtn">导入文件<input id="imp" type="file" accept=".js,.json,application/json,text/javascript" hidden></label>
      <button class="btn danger" id="rst" type="button">恢复默认数据</button></div></section>`);
    const form = root.querySelector('#af');
    form.onsubmit = async (e) => {
      e.preventDefault(); const v = readForm(SETTINGS, form), errs = PF.U.validate(SETTINGS, v);
      if (v.newPassword && v.newPassword.length < 6) errs.push('新密码至少 6 位');
      if (errs.length) return showErrs(root, errs);
      try {
        const { newPassword, ...rest } = v; await A.setSettings(rest);
        if (newPassword) await PF.Auth.changePassword(newPassword);
        document.documentElement.style.setProperty('--accent', rest.accent);   // 立即生效，无需刷新
        toast('设置已保存'); render('/admin/settings', root, await A.all());
      } catch (err) { showErrs(root, [err.message]); }
    };
    root.querySelector('#exp').onclick = () => download('data.js', A.exportJs());
    root.querySelector('#imp').onchange = async (e) => {
      const file = e.target.files[0]; if (!file) return;
      if (!confirm('导入会覆盖当前浏览器里的全部数据，确定继续吗？')) { e.target.value = ''; return; }
      try { await A.importText(await file.text()); toast('导入成功'); render('/admin/settings', root, await A.all()); } catch (err) { toast(err.message, true); }
    };
    root.querySelector('#rst').onclick = async () => { if (!confirm('确定恢复为网站默认数据吗？当前浏览器里未导出的修改会丢失。')) return; await A.reset(); toast('已恢复默认'); render('/admin/settings', root, await A.all()); };
  }

  async function render(path, root, d) {
    if (path === '/admin/login') { if (PF.Auth.isLoggedIn()) { location.hash = '#/admin'; return; } return loginPage(root); }
    if (!PF.Auth.isLoggedIn()) { location.hash = '#/admin/login'; return; }                    // 路由守卫
    d = d || (await A.all());
    const m = path.match(/^\/admin(?:\/([a-z]+))?(?:\/(new)|\/edit\/(.+))?$/), key = m && m[1], mode = m && (m[2] || (m[3] && 'edit'));
    if (!m) { location.hash = '#/admin'; return; }
    if (!key) dashboard(root, d);
    else if (key === 'profile') formPage(root, 'profile', '个人信息', PROFILE, d.profile, async (v) => { await A.setProfile(v); toast('个人信息已保存'); }, '');
    else if (key === 'settings') settingsPage(root, d);
    else if (COLL[key]) {
      const c = COLL[key];
      if (!mode) listPage(root, key, d);
      else {
        const id = m[3] ? decodeURIComponent(m[3]) : null, cur = id ? await A.get(key, id) : { date: new Date().toISOString().slice(0, 10), level: 60 };
        if (id && !cur) { toast('记录不存在', true); location.hash = '#/admin/' + key; return; }
        formPage(root, key, (id ? '编辑' : '新建') + c.title, c.fields, cur, async (v) => {
          if (id) await A.update(key, id, v); else await A.create(key, v);
          toast('已保存'); location.hash = '#/admin/' + key;
        }, '#/admin/' + key);
      }
    } else { location.hash = '#/admin'; return; }
    const lo = root.querySelector('#logout'); if (lo) lo.onclick = () => { PF.Auth.logout(); location.hash = '#/admin/login'; };
  }
  PF.Admin = { render, _t: { tagsToArr, socialsToText, textToSocials, checkSocials, COLL, PROFILE, SETTINGS } };
  if (typeof module !== 'undefined') module.exports = PF.Admin;
})();
