/* 轻量 Markdown 渲染：先转义再解析（防 XSS），支持标题/列表/引用/代码块（含高亮）/链接/图片/粗斜体，并生成目录 */
(function () {
  const PF = (window.PF = window.PF || {});
  const { esc, safeUrl } = PF.U;
  const KW = 'const|let|var|function|return|if|else|for|while|class|import|from|export|new|async|await|def|None|True|False|try|catch|except|finally|in|of|is|not|and|or|with|as|true|false|null|undefined|this|self|print|raise|lambda|yield|SELECT|FROM|WHERE|INSERT|INTO|VALUES|UPDATE|DELETE|CREATE|TABLE';
  const RE_SLASH = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`)|(\b\d+(?:\.\d+)?\b)|(\b(?:__KW__)\b)/g;
  const RE_HASH = /(#[^\n]*)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(\b\d+(?:\.\d+)?\b)|(\b(?:__KW__)\b)/g;

  // 代码高亮：注释 c / 字符串 s / 数字 n / 关键字 k
  function highlight(code, lang) {
    const base = /^(py|python|sh|bash|shell|yaml|yml)$/i.test(lang || '') ? RE_HASH : RE_SLASH;
    const re = new RegExp(base.source.replace('__KW__', KW), 'g');
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index));
      const cls = m[1] ? 'c' : m[2] ? 's' : m[3] ? 'n' : 'k';
      out += `<span class="tk-${cls}">${esc(m[0])}</span>`;
      last = m.index + m[0].length;
      if (!m[0].length) re.lastIndex++;
    }
    return out + esc(code.slice(last));
  }

  function inline(s) {
    const codes = [];
    s = String(s).replace(/\u0000/g, '').replace(/`([^`]+)`/g, (_, c) => { codes.push(c); return '\u0000' + (codes.length - 1) + '\u0000'; });
    s = esc(s);
    s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, (m, a, u) => (safeUrl(u) && !/^mailto:/i.test(u) ? `<img src="${u}" alt="${a}" loading="lazy">` : m));
    s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (m, t, u) => (safeUrl(u) ? `<a href="${u}" target="_blank" rel="noopener noreferrer">${t}</a>` : m));
    s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*([^*\s][^*]*)\*/g, '<em>$1</em>');
    return s.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${esc(codes[+i])}</code>`);
  }
  const slug = (t) => t.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '') || 'section';

  function render(src) {
    const lines = String(src || '').replace(/\r\n?/g, '\n').split('\n');
    const out = [], toc = [], used = new Set();
    let i = 0, para = [], m;
    const flush = () => { if (para.length) { out.push('<p>' + inline(para.join(' ')) + '</p>'); para = []; } };
    while (i < lines.length) {
      const ln = lines[i];
      if ((m = ln.match(/^```(\w*)\s*$/))) {                       // 代码块
        flush(); const buf = []; i++;
        while (i < lines.length && !/^```\s*$/.test(lines[i])) buf.push(lines[i++]);
        i++; out.push(`<pre class="code"><code>${highlight(buf.join('\n'), m[1])}</code></pre>`); continue;
      }
      if ((m = ln.match(/^(#{1,6})\s+(.+?)\s*#*\s*$/))) {          // 标题（2、3 级进目录）
        flush(); let id = 'h-' + slug(m[2]), n = 1; const base = id;
        while (used.has(id)) id = base + '-' + ++n;
        used.add(id); if (m[1].length <= 3 && m[1].length >= 2) toc.push({ level: m[1].length, text: m[2], id });
        out.push(`<h${m[1].length} id="${id}">${inline(m[2])}</h${m[1].length}>`); i++; continue;
      }
      if (/^(-{3,}|\*{3,})\s*$/.test(ln)) { flush(); out.push('<hr>'); i++; continue; }
      if (/^>\s?/.test(ln)) {                                      // 引用
        flush(); const buf = [];
        while (i < lines.length && /^>\s?/.test(lines[i])) buf.push(lines[i++].replace(/^>\s?/, ''));
        out.push('<blockquote>' + inline(buf.join(' ')) + '</blockquote>'); continue;
      }
      if (/^\s*([-*+]|\d+\.)\s+/.test(ln)) {                       // 列表
        flush(); const ordered = /^\s*\d+\./.test(ln), items = [];
        while (i < lines.length && /^\s*([-*+]|\d+\.)\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*([-*+]|\d+\.)\s+/, ''));
        const tag = ordered ? 'ol' : 'ul';
        out.push(`<${tag}>` + items.map((t) => '<li>' + inline(t) + '</li>').join('') + `</${tag}>`); continue;
      }
      if (!ln.trim()) { flush(); i++; continue; }
      para.push(ln.trim()); i++;
    }
    flush();
    return { html: out.join('\n'), toc };
  }
  PF.Md = { render, highlight, inline };
  if (typeof module !== 'undefined') module.exports = PF.Md;
})();
