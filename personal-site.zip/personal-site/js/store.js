/* 数据层 + 登录。所有读写都走 PF.Api（均为 async），以后换成真实后端只改这一个文件 */
(function () {
  const PF = (window.PF = window.PF || {});
  const { uid } = PF.U;
  const KEY = 'portfolio:data:v1', DIRTY = 'portfolio:dirty', TOK = 'portfolio:token';
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const ls = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } },
    del(k) { try { localStorage.removeItem(k); } catch (e) {} }
  };
  const LISTS = ['experience', 'education', 'skills', 'projects', 'posts'];
  function normalize(d) {
    const base = window.DEFAULT_DATA, o = Object.assign(clone(base), d || {});
    LISTS.forEach((k) => { if (!Array.isArray(o[k])) o[k] = []; });
    o.profile = Object.assign({}, base.profile, o.profile);
    o.settings = Object.assign({}, base.settings, o.settings);
    if (!Array.isArray(o.profile.socials)) o.profile.socials = [];
    return o;
  }
  function load() {
    let d = null; const raw = ls.get(KEY);
    if (raw) { try { d = JSON.parse(raw); } catch (e) { d = null; } }
    return normalize(d);
  }
  let data = load();
  function persist() {
    if (!ls.set(KEY, JSON.stringify(data))) throw new Error('浏览器存储已满或被禁用，无法保存');
    ls.set(DIRTY, '1');
  }
  const need = (key) => { if (!LISTS.includes(key)) throw new Error('未知的数据类型：' + key); };

  PF.Api = {
    async all() { return data; },
    async get(key, id) { need(key); return data[key].find((x) => x.id === id) || null; },
    async create(key, item) { need(key); const it = { ...item, id: uid() }; data[key].push(it); persist(); return it; },
    async update(key, id, item) {
      need(key); const i = data[key].findIndex((x) => x.id === id);
      if (i < 0) throw new Error('记录不存在'); data[key][i] = { ...item, id }; persist(); return data[key][i];
    },
    async remove(key, id) { need(key); const n = data[key].length; data[key] = data[key].filter((x) => x.id !== id); persist(); return n !== data[key].length; },
    async setProfile(p) { data.profile = { ...data.profile, ...p }; persist(); },
    async setSettings(s) { data.settings = { ...data.settings, ...s }; persist(); },
    async reset() { ls.del(KEY); ls.del(DIRTY); data = load(); },
    isDirty() { return ls.get(DIRTY) === '1'; },
    exportJs() { return '/* 由后台导出，用它替换仓库中的 js/data.js */\nwindow.DEFAULT_DATA = ' + JSON.stringify(data, null, 2) + ';\n'; },
    async importText(text) {                                   // 同时接受 data.js 和纯 JSON
      const t = String(text).trim().replace(/^\/\*[\s\S]*?\*\/\s*/, '').replace(/^window\.DEFAULT_DATA\s*=\s*/, '').replace(/;\s*$/, '');
      let o; try { o = JSON.parse(t); } catch (e) { throw new Error('文件内容无法解析'); }
      if (!o || typeof o !== 'object' || !o.profile || !o.settings) throw new Error('文件格式不正确，缺少 profile 或 settings');
      data = normalize(o); persist();
    }
  };

  // ---- 登录：密码以 SHA-256 哈希比对，登录态只保存随机 token（前端守卫仅用于演示，见 TECH_DESIGN） ----
  async function sha(s) {
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
    return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
  }
  const hashPw = (pw) => sha('portfolio-v1:' + pw);
  PF.Auth = {
    hashPw,
    async login(user, pw) {
      if (!window.crypto || !crypto.subtle) throw new Error('当前环境不支持加密接口，请使用 https 或 localhost 访问');
      if (user !== data.settings.adminUser || (await hashPw(pw)) !== data.settings.passHash) return false;
      const t = [...crypto.getRandomValues(new Uint8Array(16))].map((x) => x.toString(16).padStart(2, '0')).join('');
      ls.set(TOK, JSON.stringify({ t, exp: Date.now() + 7 * 864e5 })); return true;
    },
    isLoggedIn() { try { const o = JSON.parse(ls.get(TOK)); return !!(o && o.t && o.exp > Date.now()); } catch (e) { return false; } },
    logout() { ls.del(TOK); },
    async changePassword(pw) { await PF.Api.setSettings({ passHash: await hashPw(pw) }); }
  };
})();
