/* 网站默认数据。后台修改保存在浏览器本地；想让所有访客看到修改，
   在后台「站点设置」导出 data.js，替换本文件后提交到 GitHub 即可。 */
window.DEFAULT_DATA = {
  profile: {
    name: "陈小宇",
    title: "全栈开发者 · AI 应用探索者",
    tagline: "用 AI 把想法变成能运行的产品。",
    avatarText: "陈",
    about: "我喜欢把一个模糊的想法拆成清晰的需求，再借助 AI 一步步做成真正能用的东西。\n\n最近做了图书管理系统、成绩录入系统和一个 Chrome 图片提取插件，正在学习用 PRD、技术设计和 AGENTS.md 规范 AI 开发流程。",
    email: "hello@example.com",
    location: "中国",
    resumeUrl: "",
    socials: [{ label: "GitHub", url: "https://github.com/" }]
  },
  experience: [
    { id: "e1", org: "独立项目", role: "开发者", start: "2026-09", end: "至今", desc: "用 AI 辅助完成管理系统、浏览器插件和个人网站，并部署上线。" }
  ],
  education: [
    { id: "d1", school: "某某大学", degree: "计算机相关专业", start: "2022", end: "2026" }
  ],
  skills: [
    { id: "s1", category: "后端", name: "Python", icon: "🐍", level: 80 },
    { id: "s2", category: "后端", name: "SQLite", icon: "🗄️", level: 70 },
    { id: "s3", category: "前端", name: "JavaScript", icon: "⚡", level: 75 },
    { id: "s4", category: "前端", name: "HTML / CSS", icon: "🎨", level: 75 },
    { id: "s5", category: "前端", name: "Chrome 插件", icon: "🧩", level: 65 },
    { id: "s6", category: "工具", name: "Git / GitHub", icon: "🌿", level: 65 },
    { id: "s7", category: "工具", name: "AI 辅助开发", icon: "🤖", level: 85 }
  ],
  projects: [
    { id: "imagegrab", title: "图提取 ImageGrab", summary: "Chrome 插件：一键提取淘宝、京东、拼多多商家版详情页的全部图片，勾选后批量下载为 PNG。",
      tags: ["Chrome 插件", "Manifest V3", "JavaScript"], link: "", repo: "", cover: "", date: "2026-10-16",
      content: "## 项目简介\n\n电商运营经常要保存详情页的图片，逐张右键效率很低。图提取在页面右下角放一个按钮，点击后扫描所有图片，集中预览并批量下载。\n\n## 主要功能\n\n- 兼容懒加载、srcset 和背景图\n- 自动过滤图标、logo 和小图\n- 缩略图还原为大图\n- 统一转换为 PNG，文件名自动编号\n\n## 技术要点\n\n使用 Manifest V3，内容脚本负责提取，Service Worker 负责打开预览页和下载。" },
    { id: "library", title: "图书管理系统", summary: "Python 标准库 + SQLite 实现，零依赖，双击即可运行的图书借还管理系统。",
      tags: ["Python", "SQLite", "零依赖"], link: "", repo: "", cover: "", date: "2026-10-13",
      content: "## 项目简介\n\n一个本地运行的图书管理网站：图书、读者、借阅和归还，自动统计库存与逾期。\n\n## 亮点\n\n- 后端只用 Python 标准库，不需要安装任何依赖\n- 借期、借阅上限等业务规则在服务端校验\n- 管理员登录，密码加盐哈希存储" },
    { id: "grades", title: "成绩录入系统", summary: "按课程和学期批量录入成绩，实时统计平均分、及格率和分数段分布，可导出 CSV。",
      tags: ["Python", "SQLite", "数据统计"], link: "", repo: "", cover: "", date: "2026-10-14",
      content: "## 项目简介\n\n老师可以在表格里直接录入成绩，回车跳到下一位学生，右侧实时显示统计结果。\n\n## 亮点\n\n- 批量保存先整体校验，再统一写入\n- 学生成绩单显示学分加权平均分\n- 导出的 CSV 带 BOM，Excel 打开不乱码" }
  ],
  posts: [
    { id: "ai-workflow", title: "我的 AI 辅助开发流程：从需求到上线", summary: "直接说“帮我做个网站”结果往往不可控。先把需求写清楚，AI 才能做出你想要的东西。",
      tags: ["AI 编程", "流程"], date: "2026-10-16",
      content: "## 为什么要有流程\n\n直接对 AI 说“帮我做个网站”，结果往往不可控。先把需求写清楚，AI 才能写出你想要的东西。\n\n## 五个步骤\n\n1. **需求研究**：想清楚要解决什么问题，看看同类产品。\n2. **写 PRD**：明确做什么、不做什么。\n3. **技术设计**：确定技术栈、目录结构和数据模型。\n4. **AGENTS.md**：告诉 AI 开发规范和注意事项。\n5. **分步开发**：先跑通框架，再做核心功能，最后打磨细节。\n\n## 一个小技巧\n\n提示词里写清楚三件事：角色、细节要求、拆解后的小任务。\n\n> 每完成一个功能就用 Git 提交一次，出问题能随时回退。" },
    { id: "zero-dep", title: "零依赖也能做管理系统", summary: "只用 Python 标准库和 SQLite，就能做出可以直接打包交付的小型管理系统。",
      tags: ["Python", "后端"], date: "2026-10-13",
      content: "## 思路\n\n小型管理系统不一定需要框架。标准库的 `http.server` 加 `sqlite3`，再配一个单页前端就够用了。\n\n## 最小骨架\n\n\`\`\`python\nfrom http.server import ThreadingHTTPServer, BaseHTTPRequestHandler\n\nclass H(BaseHTTPRequestHandler):\n    def do_GET(self):\n        self.send_response(200)\n        self.end_headers()\n        self.wfile.write(b'hello')\n\nThreadingHTTPServer(('127.0.0.1', 8000), H).serve_forever()\n\`\`\`\n\n## 好处\n\n- 用户解压后双击就能运行\n- 没有依赖冲突，也不需要联网安装" },
    { id: "extension-pitfalls", title: "做 Chrome 图片插件踩过的坑", summary: "懒加载、跨域转换、缩略图还原，这几个问题几乎每个图片类插件都会遇到。",
      tags: ["Chrome 插件", "前端"], date: "2026-10-16",
      content: "## 懒加载\n\n很多图片的真实地址放在 `data-src` 里，需要同时读取多个属性，并在提取前滚动页面。\n\n## 跨域转 PNG\n\n直接在 canvas 里画跨域图片会被污染。扩展声明 host 权限后，可以先 fetch 再转换。\n\n## 缩略图\n\n右键保存的常常是缩略图，需要按各平台的地址规则还原成大图，失败时再退回原地址。" }
  ],
  settings: {
    siteTitle: "陈小宇的个人网站",
    accent: "#8fa8ff",
    footer: "© 2026 陈小宇",
    adminUser: "admin",
    passHash: "abd339e96360ba6cf85f4d1f0377dde51aaac7c04c0e0807d7a6530dc93957c0"
  }
};
