/* 路由与前台交互：hash 路由，部署在任何静态托管上都不需要服务端重写规则 */
(function () {
  const PF = window.PF, $ = (s, r) => (r || document).querySelector(s), $$ = (s, r) => [...(r || document).querySelectorAll(s)];
  let spy = null;
  const curPath = () => (location.hash.slice(1) || '/').split('?')[0];

  function scrollToId(id) {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
  }
  function bindFront(d) {
    const menu = $('#menu'), burger = $('#burger');
    const setMenu = (o) => { menu.classList.toggle('open', o); burger.setAttribute('aria-expanded', String(o)); burger.setAttribute('aria-label', o ? '关闭菜单' : '打开菜单'); };
    burger.onclick = () => setMenu(!menu.classList.contains('open'));
    $$('[data-go]').forEach((a) => a.addEventListener('click', (e) => {            // 锚点滚动（首页内直接滚动，其他页面先回首页）
      e.preventDefault(); setMenu(false);
      if (curPath() === '/') scrollToId(a.dataset.go); else { PF.pending = a.dataset.go; location.hash = '#/'; }
    }));
    $$('[data-h]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); scrollToId(a.dataset.h); }));
    const nav = $('#nav'), onScroll = () => nav.classList.toggle('scrolled', scrollY > 8);
    onScroll(); addEventListener('scroll', onScroll, { passive: true });

    $$('[data-copy]').forEach((b) => b.addEventListener('click', async () => {      // 复制邮箱
      const old = b.textContent;
      try { await navigator.clipboard.writeText(b.dataset.copy); b.textContent = '已复制到剪贴板'; }
      catch (e) { const t = document.createElement('textarea'); t.value = b.dataset.copy; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); b.textContent = '已复制到剪贴板'; } catch (e2) { b.textContent = '复制失败，请手动复制'; } t.remove(); }
      setTimeout(() => (b.textContent = old), 2000);
    }));

    const cf = $('#cf');
    if (cf) cf.addEventListener('submit', (e) => {                                  // 留言表单：校验 + 反馈（通过邮件客户端发送）
      e.preventDefault();
      const v = Object.fromEntries(new FormData(cf)), errs = PF.U.validateContact(v), msg = $('#cf-msg');
      $$('.fe', cf).forEach((s) => (s.textContent = errs[s.dataset.for] || ''));
      cf.classList.remove('ok'); msg.className = '';
      if (Object.keys(errs).length) { msg.textContent = '提交失败：请检查上面标出的内容。'; msg.className = 'bad'; return; }
      if (!d.profile.email) { msg.textContent = '发送失败：站长还没有设置联系邮箱。'; msg.className = 'bad'; return; }
      location.href = `mailto:${d.profile.email}?subject=${encodeURIComponent('来自网站的留言 - ' + v.name)}&body=${encodeURIComponent(v.message + '\n\n' + v.name + ' <' + v.email + '>')}`;
      msg.textContent = '已打开你的邮件客户端，请在其中确认发送。没有弹出的话，请直接复制上方邮箱联系我。'; msg.className = 'good'; cf.reset();
    });

    if (spy) spy.disconnect();                                                      // 导航当前区块高亮
    if (curPath() === '/' && 'IntersectionObserver' in window) {
      const links = {}; $$('#menu a[data-go]').forEach((a) => (links[a.dataset.go] = a));
      spy = new IntersectionObserver((es) => es.forEach((en) => { if (en.isIntersecting && links[en.target.id]) { Object.values(links).forEach((l) => l.classList.remove('active')); links[en.target.id].classList.add('active'); } }), { rootMargin: '-45% 0px -50% 0px' });
      Object.keys(links).forEach((id) => { const s = document.getElementById(id); if (s) spy.observe(s); });
    }
  }

  async function render() {
    const path = curPath(), app = document.getElementById('app'), d = await PF.Api.all(), isAdmin = path.startsWith('/admin');
    const ac = /^#[0-9a-f]{6}$/i.test(d.settings.accent) ? d.settings.accent : '#8fa8ff';
    document.documentElement.style.setProperty('--accent', ac);
    document.body.classList.toggle('is-admin', isAdmin);
    if (isAdmin) { PF.Stars.stop(); document.title = '后台管理 - ' + d.settings.siteTitle; await PF.Admin.render(path, app, d); window.scrollTo(0, 0); return; }
    PF.Stars.start(document.getElementById('stars'));
    let body, title = d.settings.siteTitle, m;
    if (path === '/' || path === '') body = PF.Front.home(d);
    else if ((m = path.match(/^\/project\/(.+)$/))) { const x = d.projects.find((p) => p.id === decodeURIComponent(m[1])); body = x ? PF.Front.project(x) : PF.Front.notFound(); if (x) title = x.title + ' - ' + title; }
    else if ((m = path.match(/^\/post\/(.+)$/))) { const x = d.posts.find((p) => p.id === decodeURIComponent(m[1])); body = x ? PF.Front.post(x) : PF.Front.notFound(); if (x) title = x.title + ' - ' + title; }
    else body = PF.Front.notFound();
    app.innerHTML = PF.Front.nav(d) + '<main>' + body + '</main>' + PF.Front.footer(d);
    document.title = title; bindFront(d);
    if (PF.pending) { const id = PF.pending; PF.pending = null; requestAnimationFrame(() => scrollToId(id)); } else window.scrollTo(0, 0);
  }
  const safeRender = () => render().catch((e) => { console.error(e); document.getElementById('app').innerHTML = '<p class="boot">页面出错了：' + PF.U.esc(e.message) + '</p>'; });
  addEventListener('hashchange', safeRender);
  safeRender();
})();
