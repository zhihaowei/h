/* 工具函数：转义、安全链接、表单校验（同时可在 Node 中测试） */
(function () {
  const PF = (window.PF = window.PF || {});
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // 只放行 http(s)、mailto 和相对路径，拒绝 javascript: 等协议
  const safeUrl = (u) => { u = String(u || '').trim(); return u && (!/^[a-z][a-z0-9+.-]*:/i.test(u) || /^(https?|mailto):/i.test(u)) ? u : ''; };
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  // fields: [{k,l,t,req,min,max}]；返回错误信息数组
  function validate(fields, v) {
    const errs = [];
    for (const f of fields) {
      const val = v[f.k];
      const empty = val == null || val === '' || (Array.isArray(val) && !val.length);
      if (f.req && empty) { errs.push(f.l + '不能为空'); continue; }
      if (empty) continue;
      if (typeof val === 'string' && f.max && val.length > f.max) errs.push(`${f.l}不能超过 ${f.max} 个字`);
      if (f.t === 'number') {
        if (typeof val !== 'number' || isNaN(val)) errs.push(f.l + '必须是数字');
        else if ((f.min != null && val < f.min) || (f.max != null && val > f.max)) errs.push(`${f.l}需在 ${f.min} 到 ${f.max} 之间`);
      } else if (f.t === 'url' && (!safeUrl(val) || /^mailto:/i.test(val))) errs.push(f.l + '必须是 http(s):// 开头的链接或相对路径');
      else if (f.t === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(val)) errs.push(f.l + '格式应为 YYYY-MM-DD');
      else if (f.t === 'color' && !/^#[0-9a-f]{6}$/i.test(val)) errs.push(f.l + '必须是 #RRGGBB 颜色');
      else if (f.t === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) errs.push(f.l + '格式不正确');
    }
    return errs;
  }
  // 联系表单校验：返回 {字段: 错误}，空对象表示通过
  function validateContact(v) {
    const e = {};
    if (!String(v.name || '').trim()) e.name = '请填写姓名';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v.email || '').trim())) e.email = '请填写正确的邮箱';
    if (String(v.message || '').trim().length < 10) e.message = '留言至少 10 个字';
    return e;
  }
  PF.U = { esc, safeUrl, uid, validate, validateContact };
  if (typeof module !== 'undefined') module.exports = PF.U;
})();
