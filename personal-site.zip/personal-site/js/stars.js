/* 星空背景：Canvas 粒子，缓慢闪烁 + 指针/滚动视差；移动端减少粒子；尊重 prefers-reduced-motion */
(function () {
  const PF = (window.PF = window.PF || {});
  let cv, ctx, stars = [], W = 0, H = 0, raf = 0, running = false, px = 0, py = 0, tx = 0, ty = 0, bound = false;
  const reduce = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function build() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = innerWidth; H = innerHeight;
    cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = Math.round(Math.min(220, (W * H) / (W < 640 ? 9000 : 6500)));        // 手机粒子更少
    stars = Array.from({ length: n }, () => ({ x: Math.random() * W, y: Math.random() * H, z: Math.random(), r: Math.random() * 1.1 + 0.35, p: Math.random() * 6.28, s: Math.random() * 1.4 + 0.4 }));
  }
  function draw(t) {
    ctx.clearRect(0, 0, W, H);
    px += (tx - px) * 0.05; py += (ty - py) * 0.05;
    const sy = window.scrollY, still = reduce();
    for (const s of stars) {
      const d = s.z * 16;                                                           // z 越大越近，视差越明显
      const x = (((s.x + px * d) % W) + W) % W, y = (((s.y + py * d - sy * s.z * 0.12) % H) + H) % H;
      ctx.globalAlpha = (still ? 0.75 : 0.3 + 0.7 * (0.5 + 0.5 * Math.sin((t / 1000) * s.s + s.p))) * (0.35 + 0.65 * s.z);
      ctx.fillStyle = s.z > 0.88 ? '#ffe7b0' : '#dbe5ff';
      ctx.beginPath(); ctx.arc(x, y, s.r * (0.6 + s.z * 0.8), 0, 6.283); ctx.fill();
    }
    if (running && !still) raf = requestAnimationFrame(draw);
  }
  PF.Stars = {
    start(canvas) {
      if (running) return;
      cv = canvas; ctx = cv.getContext('2d'); build(); running = true;
      if (!bound) {
        bound = true; let rt;
        addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { if (running) { build(); if (reduce()) draw(0); } }, 150); });
        addEventListener('pointermove', (e) => { tx = (e.clientX / W - 0.5) * 2; ty = (e.clientY / H - 0.5) * 2; }, { passive: true });
        document.addEventListener('visibilitychange', () => { if (document.hidden) cancelAnimationFrame(raf); else if (running && !reduce()) raf = requestAnimationFrame(draw); });
      }
      raf = requestAnimationFrame(draw);
    },
    stop() { running = false; cancelAnimationFrame(raf); }
  };
})();
