#!/usr/bin/env python3
"""图书管理系统 - 零依赖后端（Python 3.8+，仅用标准库 + SQLite）"""
import json, sqlite3, hashlib, secrets, re, sys, datetime as dt
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path

BASE = Path(__file__).parent
DB = BASE / "library.db"
LOAN_DAYS, MAX_LOANS = 30, 5      # 借期（天）/ 每人最多同时借阅数
TOKENS = {}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, salt TEXT, pwd TEXT);
CREATE TABLE IF NOT EXISTS books(id INTEGER PRIMARY KEY, isbn TEXT UNIQUE, title TEXT NOT NULL, author TEXT DEFAULT '',
  category TEXT DEFAULT '', publisher TEXT DEFAULT '', total INTEGER DEFAULT 1, available INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS readers(id INTEGER PRIMARY KEY, card_no TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  phone TEXT DEFAULT '', email TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS loans(id INTEGER PRIMARY KEY, book_id INTEGER REFERENCES books(id), reader_id INTEGER REFERENCES readers(id),
  borrowed_at TEXT, due_at TEXT, returned_at TEXT);
"""
FIELDS = {"books": ["isbn", "title", "author", "category", "publisher"],
          "readers": ["card_no", "name", "phone", "email"]}


class ApiError(Exception):
    def __init__(self, msg, code=400): self.msg, self.code = msg, code


def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON"); return c


def hp(pw, salt): return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 100_000).hex()
def today(): return dt.date.today().isoformat()


def init():
    with db() as c:
        c.executescript(SCHEMA)
        if not c.execute("SELECT 1 FROM users").fetchone():
            s = secrets.token_hex(8)
            c.execute("INSERT INTO users(username,salt,pwd) VALUES('admin',?,?)", (s, hp("admin123", s)))
        if not c.execute("SELECT 1 FROM books").fetchone():
            demo = [("9787020002207", "红楼梦", "曹雪芹", "文学", "人民文学出版社", 3),
                    ("9787544270878", "百年孤独", "加西亚·马尔克斯", "文学", "南海出版公司", 2),
                    ("9787115546081", "流畅的Python", "Luciano Ramalho", "计算机", "人民邮电出版社", 2),
                    ("9787508647357", "人类简史", "尤瓦尔·赫拉利", "历史", "中信出版社", 4)]
            c.executemany("INSERT INTO books(isbn,title,author,category,publisher,total,available) VALUES(?,?,?,?,?,?,?)",
                          [d + (d[5],) for d in demo])
            c.execute("INSERT INTO readers(card_no,name,phone) VALUES('R0001','张三','13800000001'),('R0002','李四','13800000002')")


def rows(c, sql, a=()): return [dict(r) for r in c.execute(sql, a).fetchall()]


def need(body, *keys):
    for k in keys:
        if not str(body.get(k, "")).strip(): raise ApiError(f"缺少必填项：{k}")


def num(v, name, lo=0):
    try: n = int(v)
    except (TypeError, ValueError): raise ApiError(f"{name} 必须是整数")
    if n < lo: raise ApiError(f"{name} 不能小于 {lo}")
    return n


# ---------- 业务 ----------
def stats(c):
    one = lambda q: c.execute(q).fetchone()[0] or 0
    return {"titles": one("SELECT COUNT(*) FROM books"), "copies": one("SELECT SUM(total) FROM books"),
            "available": one("SELECT SUM(available) FROM books"), "readers": one("SELECT COUNT(*) FROM readers"),
            "active": one("SELECT COUNT(*) FROM loans WHERE returned_at IS NULL"),
            "overdue": c.execute("SELECT COUNT(*) FROM loans WHERE returned_at IS NULL AND due_at<?", (today(),)).fetchone()[0]}


def list_items(c, kind, q):
    cols = FIELDS[kind]; kw = f"%{q.get('q', [''])[0].strip()}%"
    where = " OR ".join(f"{k} LIKE ?" for k in cols)
    extra = " AND available>0" if kind == "books" and q.get("available") else ""
    return rows(c, f"SELECT * FROM {kind} WHERE ({where}){extra} ORDER BY id DESC", [kw] * len(cols))


def save_item(c, kind, body, id=None):
    cols = FIELDS[kind]; need(body, "title" if kind == "books" else "card_no", *([] if kind == "books" else ["name"]))
    vals = [str(body.get(k, "")).strip() for k in cols]
    if kind == "books": vals[0] = vals[0] or None
    try:
        if kind == "books":
            total = num(body.get("total", 1), "总册数", 0)
            if id is None:
                c.execute("INSERT INTO books(isbn,title,author,category,publisher,total,available) VALUES(?,?,?,?,?,?,?)", vals + [total, total])
            else:
                old = c.execute("SELECT total,available FROM books WHERE id=?", (id,)).fetchone()
                if not old: raise ApiError("图书不存在", 404)
                avail = old["available"] + total - old["total"]
                if avail < 0: raise ApiError("总册数不能少于当前已借出的册数")
                c.execute("UPDATE books SET isbn=?,title=?,author=?,category=?,publisher=?,total=?,available=? WHERE id=?", vals + [total, avail, id])
        elif id is None:
            c.execute("INSERT INTO readers(card_no,name,phone,email) VALUES(?,?,?,?)", vals)
        else:
            c.execute("UPDATE readers SET card_no=?,name=?,phone=?,email=? WHERE id=?", vals + [id])
    except sqlite3.IntegrityError:
        raise ApiError("ISBN 已存在" if kind == "books" else "借书证号已存在")
    return {"ok": True}


def delete_item(c, kind, id):
    col = "book_id" if kind == "books" else "reader_id"
    if c.execute(f"SELECT 1 FROM loans WHERE {col}=? AND returned_at IS NULL", (id,)).fetchone():
        raise ApiError("存在未归还的借阅记录，无法删除")
    c.execute(f"DELETE FROM loans WHERE {col}=?", (id,)); c.execute(f"DELETE FROM {kind} WHERE id=?", (id,))
    return {"ok": True}


def list_loans(c, q):
    st = q.get("status", ["active"])[0]
    cond = {"active": "l.returned_at IS NULL", "overdue": "l.returned_at IS NULL AND l.due_at<?",
            "returned": "l.returned_at IS NOT NULL", "all": "1=1"}.get(st, "1=1")
    sql = f"""SELECT l.*, b.title, r.name, r.card_no, (l.returned_at IS NULL AND l.due_at<?) AS overdue
              FROM loans l JOIN books b ON b.id=l.book_id JOIN readers r ON r.id=l.reader_id WHERE {cond} ORDER BY l.id DESC"""
    return rows(c, sql, [today()] * (2 if st == "overdue" else 1))


def borrow(c, body):
    bid, rid = num(body.get("book_id"), "图书"), num(body.get("reader_id"), "读者")
    b = c.execute("SELECT * FROM books WHERE id=?", (bid,)).fetchone()
    if not b: raise ApiError("图书不存在", 404)
    if not c.execute("SELECT 1 FROM readers WHERE id=?", (rid,)).fetchone(): raise ApiError("读者不存在", 404)
    if b["available"] < 1: raise ApiError("该书已全部借出")
    if c.execute("SELECT 1 FROM loans WHERE book_id=? AND reader_id=? AND returned_at IS NULL", (bid, rid)).fetchone():
        raise ApiError("该读者已借了这本书")
    if c.execute("SELECT COUNT(*) FROM loans WHERE reader_id=? AND returned_at IS NULL", (rid,)).fetchone()[0] >= MAX_LOANS:
        raise ApiError(f"该读者已达借阅上限（{MAX_LOANS} 本）")
    due = (dt.date.today() + dt.timedelta(days=LOAN_DAYS)).isoformat()
    c.execute("INSERT INTO loans(book_id,reader_id,borrowed_at,due_at) VALUES(?,?,?,?)", (bid, rid, today(), due))
    c.execute("UPDATE books SET available=available-1 WHERE id=?", (bid,))
    return {"ok": True, "due_at": due}


def give_back(c, id):
    l = c.execute("SELECT * FROM loans WHERE id=?", (id,)).fetchone()
    if not l: raise ApiError("借阅记录不存在", 404)
    if l["returned_at"]: raise ApiError("该书已归还")
    c.execute("UPDATE loans SET returned_at=? WHERE id=?", (today(), id))
    c.execute("UPDATE books SET available=available+1 WHERE id=?", (l["book_id"],))
    return {"ok": True}


def route(method, path, q, body, token):
    if path == "/api/login" and method == "POST":
        with db() as c:
            u = c.execute("SELECT * FROM users WHERE username=?", (body.get("username", ""),)).fetchone()
        if not u or not secrets.compare_digest(u["pwd"], hp(body.get("password", ""), u["salt"])):
            raise ApiError("用户名或密码错误", 403)
        t = secrets.token_hex(16); TOKENS[t] = u["id"]; return {"token": t, "username": u["username"]}
    if token not in TOKENS: raise ApiError("请先登录", 401)
    with db() as c:
        if path == "/api/stats": return {**stats(c), "overdue_list": list_loans(c, {"status": ["overdue"]})[:8]}
        if path == "/api/password" and method == "POST":
            need(body, "password")
            if len(body["password"]) < 6: raise ApiError("新密码至少 6 位")
            s = secrets.token_hex(8)
            c.execute("UPDATE users SET salt=?,pwd=? WHERE id=?", (s, hp(body["password"], s), TOKENS[token])); return {"ok": True}
        m = re.fullmatch(r"/api/(books|readers)(?:/(\d+))?", path)
        if m:
            kind, id = m.group(1), m.group(2) and int(m.group(2))
            if method == "GET" and not id: return list_items(c, kind, q)
            if method == "POST" and not id: return save_item(c, kind, body)
            if method == "PUT" and id: return save_item(c, kind, body, id)
            if method == "DELETE" and id: return delete_item(c, kind, id)
        if path == "/api/loans" and method == "GET": return list_loans(c, q)
        if path == "/api/loans" and method == "POST": return borrow(c, body)
        m = re.fullmatch(r"/api/loans/(\d+)/return", path)
        if m and method == "POST": return give_back(c, int(m.group(1)))
    raise ApiError("接口不存在", 404)


class H(BaseHTTPRequestHandler):
    def handle_any(self):
        u = urlparse(self.path)
        if self.command == "GET" and not u.path.startswith("/api"):
            data = (BASE / "static" / "index.html").read_bytes()
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
            out, code = route(self.command, u.path, parse_qs(u.query), body, self.headers.get("Authorization", "")), 200
        except ApiError as e: out, code = {"error": e.msg}, e.code
        except json.JSONDecodeError: out, code = {"error": "请求格式错误"}, 400
        except Exception as e: out, code = {"error": f"服务器错误：{e}"}, 500
        data = json.dumps(out, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
    do_GET = do_POST = do_PUT = do_DELETE = handle_any
    def log_message(self, *a): pass


if __name__ == "__main__":
    init(); port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"图书管理系统已启动： http://localhost:{port}  （默认账号 admin / admin123，Ctrl+C 退出）")
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
