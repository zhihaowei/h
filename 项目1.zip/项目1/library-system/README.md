# 图书管理系统

零依赖：只需 Python 3.8+（内置 SQLite），无需 pip install。

## 运行
- Windows：双击 `start.bat`
- macOS / Linux：`./start.sh`（或 `python3 server.py`）
- 浏览器打开 http://localhost:8000 ，默认账号 `admin` / `admin123`（登录后请在左下角“修改密码”）
- 换端口：`python3 server.py 9000`

## 功能
图书增删改查与搜索 · 读者管理 · 借书/还书（默认借期 30 天、每人最多 5 本，可在 server.py 顶部修改）·
逾期提醒 · 库存自动增减 · 管理员登录与改密码

## 文件
- `server.py` 后端与 REST API　`static/index.html` 前端　`library.db` 首次运行自动生成（含示例数据，删除该文件即可重置）
- 服务仅监听 127.0.0.1；如需局域网访问，把 server.py 末尾的 "127.0.0.1" 改为 "0.0.0.0"
