/** 图提取 ImageGrab - 预览页：网格展示、勾选、转 PNG、批量下载 */
const $ = (s) => document.querySelector(s);
let items = [], selected = new Set(), minSide = 0, busy = false;

const isVisible = (it) => Math.min(it.width, it.height) >= minSide;
const visibleIdx = () => items.map((_, i) => i).filter((i) => isVisible(items[i]));

async function init() {
  const key = 'session_' + new URLSearchParams(location.search).get('id');
  const data = (await chrome.storage.local.get(key))[key];
  if (!data || !data.images || !data.images.length) { $('#empty').hidden = false; return; }
  items = data.images;
  $('#meta').textContent = [data.platform, data.pageTitle].filter(Boolean).join(' - ');
  $('#meta').title = data.pageUrl || '';
  render(); bind(); refresh();
}

// 用 DOM API 构建（不使用 innerHTML，避免页面标题/地址带来注入风险）
function render() {
  const grid = $('#grid'); grid.textContent = '';
  items.forEach((it, i) => {
    const card = document.createElement('label'); card.className = 'card'; card.dataset.i = i;
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.setAttribute('aria-label', '选择第 ' + (i + 1) + ' 张');
    const img = document.createElement('img'); img.className = 'thumb'; img.loading = 'lazy'; img.referrerPolicy = 'no-referrer'; img.alt = '商品图 ' + (i + 1); img.src = it.url;
    img.onerror = () => { if (it.fallback && img.src !== it.fallback) img.src = it.fallback; };   // 大图加载失败时退回原图
    const dim = document.createElement('span'); dim.className = 'dim';
    dim.append(Object.assign(document.createElement('span'), { textContent: '#' + (i + 1) }), Object.assign(document.createElement('span'), { textContent: it.width + ' × ' + it.height }));
    cb.onchange = () => { cb.checked ? selected.add(i) : selected.delete(i); card.classList.toggle('on', cb.checked); refresh(); };
    card.append(cb, img, dim); grid.append(card);
  });
}

function refresh() {                       // 更新可见性、计数、按钮状态
  document.querySelectorAll('.card').forEach((c) => { c.hidden = !isVisible(items[c.dataset.i]); });
  const vis = visibleIdx(), n = vis.filter((i) => selected.has(i)).length;
  $('#count').textContent = '已选 ' + n + ' / ' + vis.length;
  $('#dl').disabled = busy || n === 0;
}
function setAll(fn) {
  document.querySelectorAll('.card').forEach((c) => {
    const i = +c.dataset.i; if (c.hidden) return;
    const cb = c.querySelector('input'); cb.checked = fn(i); cb.onchange();
  });
}
function bind() {
  $('#all').onclick = () => setAll(() => true);
  $('#inv').onclick = () => setAll((i) => !selected.has(i));
  $('#minSide').onchange = (e) => { minSide = +e.target.value; refresh(); };
  $('#dl').onclick = downloadSelected;
}

// ---------- 转 PNG ----------
function viaImage(url) {                   // 备用方案：Image + canvas
  return new Promise((res, rej) => {
    const im = new Image(); im.crossOrigin = 'anonymous'; im.referrerPolicy = 'no-referrer';
    im.onload = () => res(im); im.onerror = () => rej(new Error('图片无法加载（可能有防盗链）')); im.src = url;
  });
}
async function loadBitmap(url) {           // 首选：扩展有 host 权限，可跨域 fetch → createImageBitmap
  try {
    const r = await fetch(url, { credentials: 'omit' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await createImageBitmap(await r.blob());
  } catch (e) { return viaImage(url); }
}
async function toPng(it) {
  let src;
  for (const u of [it.url, it.fallback].filter(Boolean)) { try { src = await loadBitmap(u); break; } catch (e) { /* 试下一个地址 */ } }
  if (!src) throw new Error('图片获取失败');
  const c = document.createElement('canvas'); c.width = src.width || src.naturalWidth; c.height = src.height || src.naturalHeight;
  c.getContext('2d').drawImage(src, 0, 0);
  if (src.close) src.close();
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('PNG 转换失败（图片过大？）'))), 'image/png'));
}

// ---------- 批量下载 ----------
async function pool(list, n, fn) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, list.length) }, async () => { while (i < list.length) { const k = i++; await fn(list[k], k); } }));
}
function showProgress(done, total) {
  $('#progress').hidden = false;
  $('#fill').style.width = (total ? (done / total) * 100 : 0) + '%';
  $('#ptext').textContent = '正在下载 ' + done + ' / ' + total;
}
async function downloadSelected() {
  const list = visibleIdx().filter((i) => selected.has(i));
  if (!list.length || busy) return;
  busy = true; refresh(); $('#result').hidden = true; showProgress(0, list.length);
  let ok = 0, done = 0; const fails = [];
  await pool(list, 3, async (idx, k) => {
    const name = '商品图_' + String(k + 1).padStart(3, '0') + '.png';          // 按下载顺序编号：商品图_001.png
    try {
      const url = URL.createObjectURL(await toPng(items[idx]));
      const r = await chrome.runtime.sendMessage({ type: 'DOWNLOAD', url, filename: name });
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      if (!r || !r.ok) throw new Error((r && r.error) || '下载失败');
      ok++;
    } catch (e) { fails.push('第 ' + (idx + 1) + ' 张（' + name + '）：' + (e.message || e)); }
    showProgress(++done, list.length);
  });
  busy = false; refresh(); $('#progress').hidden = true;
  const box = $('#result'); box.hidden = false; box.className = fails.length ? 'bad' : 'ok'; box.textContent = '';
  box.append(Object.assign(document.createElement('strong'), { textContent: fails.length ? '下载完成：成功 ' + ok + ' 张，失败 ' + fails.length + ' 张' : '全部下载完成，共 ' + ok + ' 张，已保存到浏览器默认下载目录' }));
  if (fails.length) { const ul = document.createElement('ul'); fails.forEach((t) => ul.append(Object.assign(document.createElement('li'), { textContent: t }))); box.append(ul); }
}
init();
