/**
 * 图提取 ImageGrab - Content Script
 * 1) 在淘宝/京东/拼多多详情页右下角显示「获取图片」按钮
 * 2) 点击后扫描页面图片 → 过滤 → 去重 → 发送给 background，由它打开预览页
 */
(function (root) {
  'use strict';

  const CONFIG = { MIN_SIZE: 100, SCROLL_MS: 4000, MAX_ELEMENTS: 12000, BTN_ID: 'imagegrab-btn', TOAST_ID: 'imagegrab-toast' };

  // ---------- 平台识别：只在商品详情页显示按钮。页面改版时改这里 ----------
  const RULES = [
    { name: '淘宝/天猫', host: /(^|\.)(taobao|tmall)\.com$/,
      test: (u) => /\/item(\.htm|\/)|\/detail/i.test(u.pathname) || /^(item|detail)\./.test(u.hostname) },
    { name: '京东', host: /(^|\.)jd\.com$/,
      test: (u) => /^(item|npcitem)(\.m)?\./.test(u.hostname) || /\/\d+\.html/.test(u.pathname) },
    { name: '拼多多', host: /(^|\.)(pinduoduo|yangkeduo)\.com$/,
      test: (u) => /goods|detail/i.test(u.pathname + u.hash) }
  ];
  function matchPlatform(href) {
    try { const u = new URL(href); const r = RULES.find((x) => x.host.test(u.hostname) && x.test(u)); return r ? r.name : null; }
    catch (e) { return null; }
  }

  // ---------- URL 处理 ----------
  // 补全为绝对 URL；data:/blob: 多为占位图，直接丢弃
  function toAbs(raw, base) {
    if (!raw) return null;
    raw = String(raw).trim();
    if (!raw || /^(data:|blob:|javascript:|about:)/i.test(raw)) return null;
    try { return new URL(raw, base || root.location.href).href; } catch (e) { return null; }
  }
  // srcset 取最大的一张
  function bestFromSrcset(s) {
    if (!s) return null;
    let best = null, bw = -1;
    for (const part of s.split(/,\s+/)) {
      const [u, d] = part.trim().split(/\s+/);
      const w = parseFloat(d) || 1;
      if (u && w > bw) { best = u; bw = w; }
    }
    return best;
  }
  // 把缩略图地址还原为大图（失败时由 gallery 回退到原地址）
  function upgradeUrl(url) {
    return url
      .replace(/(\.(?:jpe?g|png|gif|webp))_[^/?#]*$/i, '$1')          // 淘宝：xxx.jpg_460x460q90.jpg_.webp → xxx.jpg
      .replace(/\/n[1-9]\/(s\d+x\d+_)?jfs\//, '/n0/jfs/')              // 京东：/n5/s54x54_jfs/ → /n0/jfs/
      .replace(/\?imageView2[^#]*/i, '');                              // 拼多多：去掉裁剪参数
  }
  // 去重用的 key：忽略协议和查询参数
  const dedupKey = (u) => u.replace(/^https?:/, '').replace(/[?#].*$/, '');
  // 图标、logo、占位图等
  const JUNK = /(^|[\/_.-])(logo|icon|sprite|avatar|placeholder|blank|loading|spacer|pixel|favicon|qrcode)([\/_.-]|$)|\.svg(\?|$)/i;
  const isJunkUrl = (u) => JUNK.test(u.replace(/^https?:\/\/[^/]+/, ''));

  if (typeof module !== 'undefined') module.exports = { matchPlatform, toAbs, bestFromSrcset, upgradeUrl, dedupKey, isJunkUrl };
  if (typeof document === 'undefined' || root.__imagegrab) return;   // 测试环境 / 重复注入时直接退出
  root.__imagegrab = true;

  // ---------- 图片采集 ----------
  const IMG_ATTRS = ['src', 'data-src', 'data-lazy-src', 'data-original', 'data-lazyload', 'data-ks-lazyload', 'data-lazy', 'data-url', 'data-img', 'lazy-src', 'data-echo', 'original'];
  const SRCSET_ATTRS = ['srcset', 'data-srcset'];

  function collectCandidates() {
    const found = new Set();
    const add = (raw) => { const u = toAbs(raw); if (u) found.add(u); };
    document.querySelectorAll('img').forEach((img) => {                       // <img> + 各种懒加载属性
      IMG_ATTRS.forEach((a) => add(img.getAttribute(a)));
      SRCSET_ATTRS.forEach((a) => add(bestFromSrcset(img.getAttribute(a))));
    });
    document.querySelectorAll('picture source').forEach((s) => add(bestFromSrcset(s.getAttribute('srcset') || s.getAttribute('data-srcset'))));
    let n = 0;
    for (const el of document.body.querySelectorAll('*')) {                   // 背景图 + 非 img 元素上的 data-src
      if (++n > CONFIG.MAX_ELEMENTS) break;
      if (el.id === CONFIG.BTN_ID) continue;
      const bg = el.style.backgroundImage || getComputedStyle(el).backgroundImage;
      if (bg && bg !== 'none') for (const m of bg.matchAll(/url\((['"]?)(.*?)\1\)/g)) add(m[2]);
      if (el.tagName !== 'IMG') add(el.getAttribute('data-src'));
    }
    return [...found];
  }

  // 加载图片取得真实尺寸（用于过滤小图）
  function probe(url, timeout = 8000) {
    return new Promise((resolve) => {
      const im = new Image();
      const t = setTimeout(() => { im.src = ''; resolve(null); }, timeout);
      im.onload = () => { clearTimeout(t); resolve({ width: im.naturalWidth, height: im.naturalHeight }); };
      im.onerror = () => { clearTimeout(t); resolve(null); };
      im.src = url;
    });
  }
  // 简单并发池
  async function pool(items, n, fn) {
    const out = new Array(items.length); let i = 0;
    await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
      while (i < items.length) { const k = i++; out[k] = await fn(items[k], k); }
    }));
    return out;
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // 逐屏滚动以触发懒加载，结束后回到原位置
  async function autoScroll() {
    const y0 = root.scrollY, step = Math.max(root.innerHeight * 0.8, 400), t0 = Date.now();
    let y = 0;
    while (y < document.documentElement.scrollHeight && Date.now() - t0 < CONFIG.SCROLL_MS) {
      y += step; root.scrollTo({ top: y, behavior: 'instant' }); await sleep(200);
    }
    root.scrollTo({ top: y0, behavior: 'instant' });
  }

  async function extractImages() {
    await autoScroll();
    const seen = new Set(), list = [];
    for (const orig of collectCandidates()) {
      if (isJunkUrl(orig)) continue;
      const up = upgradeUrl(orig), k = dedupKey(up);
      if (seen.has(k)) continue;
      seen.add(k); list.push({ up, orig });
    }
    const res = await pool(list, 6, async ({ up, orig }) => {
      let s = await probe(up);
      if (s) return { url: up, fallback: up !== orig ? orig : null, ...s };
      if (up !== orig && (s = await probe(orig))) return { url: orig, fallback: null, ...s };
      return null;
    });
    return res.filter((r) => r && r.width >= CONFIG.MIN_SIZE && r.height >= CONFIG.MIN_SIZE);   // 过滤小图
  }

  // ---------- 按钮与提示 ----------
  let running = false, toastTimer;
  function toast(msg) {
    let t = document.getElementById(CONFIG.TOAST_ID);
    if (!t) { t = document.createElement('div'); t.id = CONFIG.TOAST_ID; document.documentElement.appendChild(t); }
    t.textContent = msg; clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.remove(), 3500);
  }
  function setBtn(text, disabled) {
    const b = document.getElementById(CONFIG.BTN_ID);
    if (b) { b.textContent = text; b.disabled = disabled; }
  }
  async function run() {
    if (running) return;
    running = true; setBtn('提取中…', true); toast('正在扫描页面图片，请稍候…');
    try {
      const images = await extractImages();
      if (!images.length) { toast('没有找到符合条件的图片，请确认当前是商品详情页后重试'); return; }
      const r = await chrome.runtime.sendMessage({ type: 'IMAGES_EXTRACTED', images, pageTitle: document.title, pageUrl: location.href, platform: matchPlatform(location.href) || '' });
      if (!r || !r.ok) throw new Error((r && r.error) || '无法打开预览页');
      toast('已提取 ' + images.length + ' 张图片，已在新标签页打开');
    } catch (e) { toast('提取失败：' + (e && e.message || e)); }
    finally { running = false; setBtn('获取图片', false); }
  }
  function sync() {                                  // 详情页显示按钮，其他页面移除（兼容单页应用跳转）
    const exists = !!document.getElementById(CONFIG.BTN_ID);
    if (matchPlatform(location.href)) {
      if (exists) return;
      const b = document.createElement('button');
      b.id = CONFIG.BTN_ID; b.type = 'button'; b.textContent = '获取图片'; b.onclick = run;
      document.documentElement.appendChild(b);
    } else if (exists) document.getElementById(CONFIG.BTN_ID).remove();
  }
  chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'EXTRACT') run(); });   // 工具栏图标触发
  sync(); setInterval(sync, 1000);
})(typeof globalThis !== 'undefined' ? globalThis : this);
