/* 图提取官网交互：移动端菜单、导航高亮与吸顶阴影、滚动入场、Hero 示意图勾选 */
(function () {
  'use strict';
  var nav = document.getElementById('nav'), burger = document.getElementById('burger'), menu = document.getElementById('menu');

  // 移动端汉堡菜单
  function setMenu(open) { menu.classList.toggle('open', open); burger.setAttribute('aria-expanded', String(open)); burger.setAttribute('aria-label', open ? '关闭菜单' : '打开菜单'); }
  burger.addEventListener('click', function () { setMenu(!menu.classList.contains('open')); });
  menu.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });

  // 滚动后导航加阴影
  function onScroll() { nav.classList.toggle('scrolled', window.scrollY > 8); }
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true });

  // 入场动画：区块进入视口时淡入上移一次
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });

    // 导航当前区块高亮
    var links = {};
    menu.querySelectorAll('a[href^="#"]').forEach(function (a) { links[a.getAttribute('href').slice(1)] = a; });
    var spy = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting || !links[e.target.id]) return;
        Object.keys(links).forEach(function (k) { links[k].classList.toggle('active', k === e.target.id); });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    Object.keys(links).forEach(function (id) { var s = document.getElementById(id); if (s) spy.observe(s); });
  } else {
    document.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('in'); });
  }

  // Hero 示意图：点击图片勾选，计数同步更新
  var tiles = document.querySelectorAll('#demoGrid .tile'), count = document.getElementById('demoCount');
  function updateCount() {
    var n = document.querySelectorAll('#demoGrid .tile.on').length;
    count.textContent = '已选 ' + n + ' / ' + tiles.length;
  }
  tiles.forEach(function (t) {
    t.addEventListener('click', function () { var on = t.classList.toggle('on'); t.setAttribute('aria-pressed', String(on)); updateCount(); });
  });
})();
