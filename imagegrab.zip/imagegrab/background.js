/** 图提取 ImageGrab - Service Worker：保存提取结果并打开预览页；执行下载；工具栏图标入口 */
const pending = new Map();          // 下载 id → 等待下载结束的 resolve

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'IMAGES_EXTRACTED') {
    openGallery(msg).then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;                    // 异步响应
  }
  if (msg && msg.type === 'DOWNLOAD') { downloadFile(msg).then(sendResponse); return true; }
});

// 结果写入 storage（避免通过 URL 传大数据），再打开预览页；只保留最近 5 次
async function openGallery(payload) {
  const id = Date.now().toString(36);
  await chrome.storage.local.set({ ['session_' + id]: payload });
  const keys = Object.keys(await chrome.storage.local.get(null)).filter((k) => k.startsWith('session_')).sort();
  if (keys.length > 5) await chrome.storage.local.remove(keys.slice(0, -5));
  await chrome.tabs.create({ url: chrome.runtime.getURL('gallery.html?id=' + id) });
}

// 下载并等到真正完成（成功/中断）后再返回结果
async function downloadFile({ url, filename }) {
  try {
    const id = await chrome.downloads.download({ url, filename, conflictAction: 'uniquify', saveAs: false });
    const state = await new Promise((resolve) => {
      pending.set(id, resolve);
      chrome.downloads.search({ id }).then(([it]) => { if (it && it.state !== 'in_progress') { pending.delete(id); resolve(it.state); } });
    });
    return state === 'complete' ? { ok: true } : { ok: false, error: '下载被中断' };
  } catch (e) { return { ok: false, error: e.message || String(e) }; }
}
chrome.downloads.onChanged.addListener((d) => {
  if (d.state && d.state.current !== 'in_progress' && pending.has(d.id)) { pending.get(d.id)(d.state.current); pending.delete(d.id); }
});

// 点击工具栏图标：向当前页发送提取指令；若页面没有注入脚本则临时注入
chrome.action.onClicked.addListener(async (tab) => {
  try { await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT' }); }
  catch (e) {
    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content.css'] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT' });
    } catch (err) {
      chrome.action.setBadgeText({ tabId: tab.id, text: '×' });
      setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: '' }), 2000);
    }
  }
});
